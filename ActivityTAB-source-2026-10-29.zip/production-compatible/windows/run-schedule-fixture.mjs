import {maintenance} from './dist/service.mjs';await maintenance({flush:false});
