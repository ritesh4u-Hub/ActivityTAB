import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {spawn} from 'node:child_process';
import {createHmac} from 'node:crypto';
import {mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const root=process.cwd(),dir=mkdtempSync(join(tmpdir(),'activitytab-meetings-')),origin='http://127.0.0.1:3201',base=origin+'/ActivityTAB',pass='Meeting-Test-Only-2026!';
const child=spawn(process.execPath,[join(root,'windows/dist/server.mjs')],{env:{...process.env,ACTIVITYTAB_DATA:dir,ACTIVITYTAB_ORIGIN:origin,ACTIVITYTAB_DEV:'1',PORT:'3201',ACTIVITYTAB_TURN_URLS:'turn:127.0.0.1:1?transport=udp',ACTIVITYTAB_TURN_SECRET:'Fixture-only-TURN-shared-secret'},stdio:['ignore','pipe','pipe']});let logs='';child.stderr.on('data',d=>logs+=d);
async function call(path,body,cookie,method=body?'POST':'GET',raw=false){const r=await fetch(base+'/api/'+path,{method,headers:{Origin:origin,...(cookie?{Cookie:cookie}:{}),...(!raw&&body?{'Content-Type':'application/json'}:{})},body:body?(raw?body:JSON.stringify(body)):undefined});return {status:r.status,data:raw?await r.arrayBuffer():await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]}}
let checks=0;function check(ok,message){checks++;assert.ok(ok,message)}
try{
 await new Promise((resolve,reject)=>{child.stdout.on('data',d=>{if(String(d).includes('listening'))resolve()});child.on('exit',()=>reject(Error(logs)))});
 let r=await call('auth/setup',{code:readFileSync(join(dir,'first-admin-setup.txt'),'utf8'),name:'Meeting organiser',email:'admin@meeting.invalid',password:pass,confirm:pass});const admin=r.cookie;
 for(const name of ['Invited','Outsider'])await call('members',{name,email:name.toLowerCase()+'@meeting.invalid',role:'executive',department:'Test'},admin);
 const state=(await call('state',null,admin)).data,me=state.me,invited=state.members.find(m=>m.name==='Invited'),outsider=state.members.find(m=>m.name==='Outsider'),cookies={};
 for(const member of [invited,outsider]){const invitation=await call('auth/invite',{member:member.id},admin);r=await call('auth/activate',{token:new URL(invitation.data.url).searchParams.get('token'),password:pass,confirm:pass});cookies[member.id]=r.cookie}
 const payload={title:'Confidential budget review',kind:'online',members:[me.id,invited.id],start:new Date(Date.now()+60000).toISOString(),end:new Date(Date.now()+3600000).toISOString(),reminder:15};
 const race=await Promise.all([call('meetings',payload,admin),call('meetings',payload,cookies[invited.id])]);check(race.filter(r=>r.status===200).length===1&&race.filter(r=>r.status===409).length===1,'Concurrent booking must have one winner');
 // The invited member can also be the winning organiser; use the actual owner.
 const mid=race.find(r=>r.status===200).data.id;let detail=(await call('meetings/'+mid,null,admin)).data;const owner=detail.owner===me.id?admin:cookies[invited.id];
 check((await call('meetings/'+mid,null,cookies[outsider.id])).status===404,'Uninvited employees cannot open a guessed meeting ID');
 check((await call('meetings',null,cookies[outsider.id])).data.meetings.length===0,'Meeting list excludes unrelated meetings');
 check((await call('performance',null,cookies[outsider.id])).status===403,'Runtime metrics are admin-only');const health=(await call('performance',null,admin)).data;check(typeof health.eventLoopP95ms==='number'&&health.queues.uploads===0,'Bounded runtime metrics are available to admin');
 const day=new Date(payload.start).toLocaleDateString('en-CA',{timeZone:'Asia/Kolkata'}),availability=(await call('availability?member='+invited.id+'&day='+day,null,cookies[outsider.id])).data;
 check(availability.slots.length===1&&Object.keys(availability.slots[0]).sort().join(',')==='end,start','Public availability exposes only time slots');
 const notes='Decisions\nApprove the revised plan.\nAction: Owner to submit report.';
 check((await call('meetings/'+mid,{action:'notes',notes,version:0},cookies[invited.id],'PATCH')).status===200,'Participant can save manual notes');
 check((await call('meetings/'+mid,{action:'notes',notes:'stale',version:0},admin,'PATCH')).status===409,'Concurrent notes do not overwrite newer notes');
 check((await call('meetings/'+mid,{action:'notes',notes:'leak',version:1},cookies[outsider.id],'PATCH')).status===404,'Uninvited notes writes rejected');
 const db=new DatabaseSync(join(dir,'activitytab.sqlite'));
 check(db.prepare('SELECT COUNT(*) n FROM notifications WHERE meeting=?').get(mid).n===2,'Invitations go to every attendee');
 check((await call('state',null,cookies[outsider.id])).data.notifications.every(n=>n.meeting!==mid),'No notification leakage to outsiders');
 const sa='test-session-admin',si='test-session-invited';
 const rtc=(await call('meetings/'+mid+'/rtc',null,admin)).data;check(rtc.relayConfigured&&rtc.iceServers.length===1,'Meeting participant receives relay configuration');const issued=rtc.iceServers[0];check(issued.credential===createHmac('sha1','Fixture-only-TURN-shared-secret').update(issued.username).digest('base64'),'TURN credentials use the expected expiring HMAC');check(rtc.expiresAt>Date.now()&&rtc.expiresAt<=Date.now()+3600000,'TURN credential expiry is bounded');check(!JSON.stringify(rtc).includes('Fixture-only-TURN-shared-secret'),'Shared TURN secret never leaves the server');check((await call('meetings/'+mid+'/rtc',null,cookies[outsider.id])).status===404,'Uninvited employee cannot obtain call relay credentials');
 check((await call('meetings/'+mid+'/presence',{session:sa},admin)).status===200,'Invited organiser can join in join window');
 check((await call('meetings/'+mid+'/presence',{session:si},cookies[invited.id])).status===200,'Other participant can join');
 check((await call('meetings/'+mid+'/presence',{session:'outsider-session'},cookies[outsider.id])).status===404,'Uninvited call join rejected');
 const live=await call('meetings/'+mid+'/live',null,admin);
 check(live.status===200 && live.data.people.some(p=>p.id===me.id) && live.data.people.some(p=>p.id===invited.id),'Schema 6 live meeting includes active participants');
 check((await call('meetings/'+mid+'/live',null,cookies[outsider.id])).status===404,'Live polling stays private');
 check(db.prepare('SELECT MAX(version) n FROM schema_migrations').get().n===6,'Schema 6 only');
 check(!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='meeting_guests'").get(),'No guest schema');

 check((await call('meetings/'+mid+'/signals',{session:sa,recipient:invited.id,peerSession:si,payload:{type:'offer',sdp:{type:'offer',sdp:'fixture'}}},admin)).status===200,'Private signaling accepts current participant sessions');
 check((await call('meetings/'+mid+'/signals?session='+si,null,cookies[invited.id])).data.signals.length===1,'Signal delivered to intended participant');
 check((await call('meetings/'+mid+'/signals?session='+sa,null,cookies[outsider.id])).status===404,'Outsider cannot read signaling');
 const hostCookie=detail.host===me.id?admin:cookies[invited.id],nonHost=detail.host===me.id?cookies[invited.id]:admin,newHost=detail.host===me.id?invited.id:me.id;
 check((await call('meetings/'+mid+'/recordings',{mime:'video/webm'},nonHost)).status===403,'Only host can start recording');
 r=await call('meetings/'+mid+'/recordings',{mime:'video/webm'},hostCookie);check(r.status===200,'Joined host can start recording');const rid=r.data.id;
 check((await call('meetings/'+mid+'/recordings/'+rid+'?part=0',new Uint8Array([1,2,3]),hostCookie,'POST',true)).status===200,'Recording chunk accepted');
 check((await call('meetings/'+mid+'/recordings/'+rid+'?part=1',new Uint8Array([4,5]),hostCookie,'POST',true)).status===200,'Next recording chunk accepted');
 check((await call('meetings/'+mid+'/recordings/'+rid,null,cookies[outsider.id],'GET',true)).status===404,'Recording cannot be downloaded by outsider');
 check((await call('meetings/'+mid+'/recordings/'+rid,{complete:true},hostCookie,'PATCH')).status===200,'Recorder can finish recording');
 const recording=await call('meetings/'+mid+'/recordings/'+rid,null,nonHost,'GET',true);check([...new Uint8Array(recording.data)].join(',')==='1,2,3,4,5','Recording streams ordered chunks to participant');
 check((await call('meetings/'+mid,{action:'host',member:outsider.id},hostCookie,'PATCH')).status===400,'Host cannot transfer to outsider');
 check((await call('meetings/'+mid,{action:'host',member:newHost},hostCookie,'PATCH')).status===200,'Host can transfer to invited participant');
 check((await call('meetings/'+mid,{action:'host',member:detail.host},hostCookie,'PATCH')).status===403,'Previous host loses host permissions');
 check((await call('meetings/'+mid,{action:'cancel'},owner,'PATCH')).status===200,'Organiser can cancel');
 check((await call('availability?member='+invited.id+'&day='+day,null,cookies[outsider.id])).data.slots.length===0,'Cancellation releases busy time');
 r=await call('meetings',{...payload,kind:'offline',title:'Private doctor appointment',members:[]},cookies[invited.id]);check(r.status===200,'Employee can book a personal offline appointment');const offline=r.data.id;
 check((await call('meetings/'+offline,null,admin)).status===404,'Admin cannot open another employee personal meeting');
 check((await call('availability?member='+invited.id+'&day='+day,null,admin)).data.slots.length===1,'Offline meeting reserves visible busy time');
 check((await call('meetings/'+offline+'/presence',{session:'offline-session'},cookies[invited.id])).status===400,'Offline booking has no call room');
 db.prepare("INSERT INTO settings(key,value) VALUES('reminders',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(JSON.stringify({beforeHours:24,repeatHours:24,escalateHours:48,workStart:0,workEnd:1,weekdaysOnly:false,includeSaturday:true,holidays:[],timeZone:'Asia/Kolkata'}));await call('maintenance',{},admin);await call('maintenance',{},admin);check(db.prepare("SELECT COUNT(*) n FROM notifications WHERE meeting=? AND id LIKE 'meeting-reminder:%'").get(offline).n===1,'Offline reminders are sent once, independent of task working hours');
 const form=new FormData();form.append('file',new Blob([new Uint8Array([255,216,255,217])],{type:'image/jpeg'}),'photo.jpg');
 const upload=await fetch(base+'/api/profile/photo',{method:'POST',headers:{Origin:origin,Cookie:cookies[invited.id]},body:form});check(upload.status===200,'Employee can upload own photo');
 const photo=(await call('state',null,cookies[invited.id])).data.me.photo;check(!!photo,'Profile photo returned in state');
 check((await call('photos/'+photo,null,admin,'GET',true)).status===200,'Authenticated colleagues can see profile photo');
 check((await call('photos/'+photo,null,null,'GET',true)).status===401,'Profile photo requires authentication');
 const bad=new FormData();bad.append('file',new Blob(['<svg/>'],{type:'image/svg+xml'}),'bad.jpg');check((await fetch(base+'/api/profile/photo',{method:'POST',headers:{Origin:origin,Cookie:admin},body:bad})).status===400,'Photo endpoint rejects non-JPEG content');
 // Large fixture remains private and is never used against the live server.
 db.exec('BEGIN');const insert=db.prepare("INSERT INTO meetings(id,title,kind,owner,host,start,end,created,updated) VALUES(?,?,'offline',?,?,?,?,?,?)"),attend=db.prepare('INSERT INTO meeting_members VALUES(?,?)');
 for(let i=0;i<15000;i++){const id='load-'+i,stamp=new Date(Date.now()-(i+10)*86400000).toISOString();insert.run(id,'Historical meeting '+i,me.id,me.id,stamp,new Date(Date.parse(stamp)+1800000).toISOString(),stamp,stamp);attend.run(id,me.id)}db.exec('COMMIT');
 const timings=[];for(let i=0;i<12;i++){const t=performance.now();await call('availability?member='+me.id+'&day='+day,null,admin);await call('meetings?scope=past',null,admin);timings.push(performance.now()-t)}timings.sort((a,b)=>a-b);console.log('Large-fixture paired availability + paginated meeting requests: p95 '+Math.round(timings.at(-1))+' ms (15,000 historical meetings, local machine).');
 const page=(await call('meetings?scope=past',null,admin)).data;check(page.meetings.length===30&&page.next,'Meeting page size stays bounded with 15,000 records');
 const page2=(await call('meetings?scope=past&cursor='+encodeURIComponent(page.next),null,admin)).data;check(page2.meetings.length===30&&!page2.meetings.some(m=>page.meetings.some(p=>p.id===m.id)),'Keyset pagination does not repeat meetings');
 const stateBefore=(await call('state',null,admin)).data;check(!('meetings' in stateBefore),'Meeting history is not included in dashboard payload');
 const backup=await call('backups/run',{},admin);check(backup.status===200&&backup.data.ok,'Backup includes recording chunks and photo');
 const folder=join(dir,'backups',backup.data.name);check(JSON.parse(readFileSync(join(folder,'manifest.json'),'utf8')).files.length===3,'Backup verifies the two chunks and profile photo');db.close();
 console.log('PASS: '+checks+' meeting/profile integration checks. No production data or external push used.');
}finally{child.kill();await new Promise(r=>child.once('exit',r));rmSync(dir,{recursive:true,force:true});if(logs.includes('Request failed'))console.log(logs)}
