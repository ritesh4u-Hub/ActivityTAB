export function nextDue(due:string,frequency:string,anchorDay?:number){const d=new Date(new Date(due).getTime()+330*60000);if(frequency==='daily')d.setUTCDate(d.getUTCDate()+1);else if(frequency==='weekly')d.setUTCDate(d.getUTCDate()+7);else if(frequency==='monthly'){const day=anchorDay||d.getUTCDate();d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()+1);const last=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();d.setUTCDate(Math.min(day,last))}else throw Error('Invalid recurrence');return new Date(d.getTime()-330*60000).toISOString()}

export function isWorkingDay(value:string|Date,config:any){
 const local=new Date(new Date(value).getTime()+330*60000),day=local.getUTCDay(),date=local.toISOString().slice(0,10);
 if((config.holidays||[]).some((holiday:any)=>holiday.date===date))return false;
 return !config.weekdaysOnly||(day!==0&&(day!==6||config.includeSaturday===true));
}
export function nextScheduledDue(due:string,frequency:string,anchorDay:number|undefined,config:any){
 let next=nextDue(due,frequency,anchorDay);
 if(frequency==='daily')while(!isWorkingDay(next,config))next=nextDue(next,'daily');
 return next;
}

// Stored in the existing frequency column so old recurring series keep their format.
export function encodeRecurrence(frequency:string,interval:unknown,dates:unknown,due:string){
 if(['once','daily','weekly','monthly'].includes(frequency))return frequency;
 if(frequency==='interval'){
  const count=Number(interval);if(!Number.isInteger(count)||count<2||count>365)throw Error('Enter an interval from 2 to 365 days');
  return 'interval:'+count;
 }
 if(frequency==='dates'){
  if(!Array.isArray(dates)||dates.length<1||dates.length>100)throw Error('Choose between 1 and 100 additional dates');
  const first=new Date(Date.parse(due)+330*60000).toISOString().slice(0,10);
  const unique=new Set<string>();for(const value of dates){
   if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value))throw Error('Choose valid calendar dates');
   const parsed=new Date(value+'T00:00:00Z');if(!Number.isFinite(parsed.getTime())||parsed.toISOString().slice(0,10)!==value||value<=first)throw Error('Additional dates must be valid and after the first deadline');
   unique.add(value);
  }
  return 'dates:'+Array.from(unique).sort().join(',');
 }
 throw Error('Invalid recurrence');
}
export function nextCustomDue(due:string,frequency:string):string|null{
 const local=new Date(Date.parse(due)+330*60000);
 if(/^interval:(?:[2-9]|[1-9]\d|[12]\d\d|3[0-5]\d|36[0-5])$/.test(frequency)){local.setUTCDate(local.getUTCDate()+Number(frequency.slice(9)));return new Date(local.getTime()-330*60000).toISOString()}
 if(frequency.startsWith('dates:')){
  const current=local.toISOString().slice(0,10),next=frequency.slice(6).split(',').find(x=>x>current);
  if(!next)return null;
  const [year,month,day]=next.split('-').map(Number);local.setUTCFullYear(year,month-1,day);return new Date(local.getTime()-330*60000).toISOString();
 }
 throw Error('Invalid recurrence');
}
export function recurrenceLabel(frequency:string){if(frequency.startsWith('interval:'))return 'Every '+frequency.slice(9)+' days';if(frequency.startsWith('dates:'))return 'Specific dates';return frequency==='once'?'One-time task':frequency}
