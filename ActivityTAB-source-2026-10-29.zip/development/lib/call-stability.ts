// Presence is a signalling hint, not proof that an established media path died.
// A replacement session is authoritative; a missing heartbeat gets recovery time.
export function absentPeerExpired(entry:{session:string;missingSince?:number},presence:{member:string;session:string}[],member:string,stamp:number){
 const current=presence.find(p=>p.member===member);
 if(current){entry.missingSince=undefined;return current.session!==entry.session}
 entry.missingSince??=stamp;
 return stamp-entry.missingSince>=90000;
}
// Capped TURN credentials may not extend near a meeting's end. Refresh at most
// once a minute there, and never restart a working media connection to do so.
export function nextRelayRefresh(expiresAt:number,stamp:number){return Math.max(stamp+60000,expiresAt-600000)}
