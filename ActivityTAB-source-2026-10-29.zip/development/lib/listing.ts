import {one,rows,now} from './service';
import {taskVisibility,notificationVisibility} from './task-access';
const roles=(member:string)=>[{sql:'t.assignee=?',args:[member]},{sql:'t.creator=? AND t.assignee<>?',args:[member,member]},{sql:'t.escalation_manager=? AND t.escalated_at IS NOT NULL AND t.assignee<>? AND t.creator<>?',args:[member,member,member]}];
const closed="CASE WHEN t.status IN ('completed','cancelled') THEN 1 ELSE 0 END";
const fail=(message:string):never=>{throw Object.assign(Error(message),{status:400})};
function cursor(url:URL,length:number){const value=url.searchParams.get('cursor');if(!value)return null;if(value.length>500)fail('Invalid page cursor');try{const c=JSON.parse(value);if(!Array.isArray(c)||c.length!==length||c.some(x=>!['string','number'].includes(typeof x)))fail('Invalid page cursor');return c}catch{fail('Invalid page cursor')}}
function term(url:URL){const q=(url.searchParams.get('q')||'').slice(0,100),tokens=q.match(/[\p{L}\p{N}_]+/gu)?.slice(0,10)||[];return {q,match:tokens.map(t=>'"'+t+'"*').join(' AND ')}}
export const taskColumns=`t.id,t.title,substr(t.description,1,160) AS description,t.assignee,t.creator,t.due,t.priority,t.status,t.frequency,t.required,t.approval,t.parent,t.created,t.submitted,t.completed,t.escalation_manager,t.escalation_hours,t.escalated_at,(SELECT COUNT(*) FROM documents d WHERE d.task=t.id) AS documentCount`;
export async function taskPage(url:URL,member:string){const access=taskVisibility('t',member),where=[access.sql],args:any[]=[...access.args],filter=url.searchParams.get('status')||'all',scope=url.searchParams.get('scope');
 if(scope==='mine'){where.push('t.assignee=?');args.push(member)}if(scope==='recurring')where.push("t.frequency!='once'");
 if(filter==='overdue'){where.push("t.status IN ('pending','progress','returned') AND t.due<?");args.push(now())}else if(filter!=='all'){if(!['pending','progress','returned','submitted','completed','cancelled'].includes(filter))fail('Invalid task status');where.push('t.status=?');args.push(filter)}
 const priority=url.searchParams.get('priority')||'all';if(priority!=='all'){if(!['low','medium','high'].includes(priority))fail('Invalid priority');where.push('t.priority=?');args.push(priority)}
 const {q,match}=term(url);if(q){if(!match)where.push('0');else{where.push('(t.rowid IN (SELECT rowid FROM task_search WHERE task_search MATCH ?) OR t.assignee IN (SELECT id FROM members WHERE name LIKE ?))');args.push(match,'%'+q+'%')}}
 const filters=where.slice(1),filterArgs=args.slice(access.args.length),branches=roles(member);const countRows=await rows(branches.map(b=>'SELECT COUNT(*) n FROM tasks t WHERE '+b.sql+(filters.length?' AND '+filters.join(' AND '):'')).join(' UNION ALL '),...branches.flatMap(b=>[...b.args,...filterArgs]));const total=countRows.reduce((n,r)=>n+r.n,0),c=cursor(url,3);
 if(c){where.push(`(${closed},t.due,t.id)>(?,?,?)`);args.push(...c)}
 const restrictions=where.slice(1).join(' AND '),restrictionArgs=args.slice(access.args.length);
 const list=await rows(branches.map(b=>`SELECT * FROM (SELECT ${taskColumns},${closed} AS sortClosed FROM tasks t WHERE ${b.sql}${restrictions?' AND '+restrictions:''} ORDER BY ${closed},t.due,t.id LIMIT 101)`).join(' UNION ALL ')+' ORDER BY sortClosed,due,id LIMIT 101',...branches.flatMap(b=>[...b.args,...restrictionArgs])),hasMore=list.length>100;if(hasMore)list.pop();const last=list.at(-1);
 return {tasks:list,total,next:hasMore?JSON.stringify([['completed','cancelled'].includes(last.status)?1:0,last.due,last.id]):null};
}
export async function documentPage(url:URL,member:string,task?:string){const access=taskVisibility('t',member),where=[access.sql],args:any[]=[...access.args];if(task){where.push('d.task=?');args.push(task)}const {q,match}=term(url);if(q){where.push(match?'d.rowid IN (SELECT rowid FROM document_search WHERE document_search MATCH ?)':'0');if(match)args.push(match)}
 // A broad filename match must not scan everybody's documents for an employee
 // with a small task scope. Bound this planning probe; never cache access decisions.
 const smallScope=!!task||(await one('SELECT COUNT(*) n FROM (SELECT t.id FROM tasks t WHERE '+access.sql+' LIMIT 2001)',...access.args)).n<=2000;
 const from=smallScope?'tasks t CROSS JOIN documents d ON d.task=t.id':'documents d JOIN tasks t ON t.id=d.task';
 const total=(await one('SELECT COUNT(*) n FROM '+from+' WHERE '+where.join(' AND '),...args)).n,c=cursor(url,2);if(c){where.push('(d.created,d.id)<(?,?)');args.push(...c)}
 // Large result sets can stop after 101 rows in the date index rather than
 // materialising and sorting the entire matching archive on each page.
 const listFrom=!smallScope&&q&&total>=10000?'documents d INDEXED BY documents_created_id JOIN tasks t ON t.id=d.task':from;
 const list=await rows('SELECT d.*,t.title AS taskTitle FROM '+listFrom+' WHERE '+where.join(' AND ')+' ORDER BY d.created DESC,d.id DESC LIMIT 101',...args),more=list.length>100;if(more)list.pop();const last=list.at(-1);
 return {documents:list,total,next:more?JSON.stringify([last.created,last.id]):null};
}
export async function noticePage(url:URL,member:string){const visible=notificationVisibility(member),where=['n.recipient=?',visible.sql],args:any[]=[member,...visible.args],c=cursor(url,2);if(c){where.push('(n.created,n.id)<(?,?)');args.push(...c)}const list=await rows('SELECT n.* FROM notifications n WHERE '+where.join(' AND ')+' ORDER BY n.created DESC,n.id DESC LIMIT 101',...args),more=list.length>100;if(more)list.pop();const last=list.at(-1);return {notifications:list,next:more?JSON.stringify([last.created,last.id]):null}}
export async function dashboard(member:string){const stamp=now(),branches=roles(member),related=branches.map(b=>'SELECT t.status,t.due,t.assignee FROM tasks t WHERE '+b.sql).join(' UNION ALL '),roleArgs=branches.flatMap(b=>b.args);
 // Count indexed status ranges directly. Repeated dashboard polls must not
 // materialise the full task archive and evaluate seven expressions per row.
 const counters=[['total',''],['completed'," AND t.status='completed'"],['cancelled'," AND t.status='cancelled'"],['progress'," AND t.status='progress'"],['review'," AND t.status='submitted'"],['active'," AND t.status IN ('pending','progress','returned','submitted')"],['overdue'," AND t.status IN ('pending','progress','returned') AND t.due<?"]];
 const counts=await rows(branches.map(b=>'SELECT '+counters.map(([name,condition])=>`(SELECT COUNT(*) FROM tasks t WHERE ${b.sql}${condition}) AS ${name}`).join(',')).join(' UNION ALL '),...branches.flatMap(b=>counters.flatMap(([name])=>[...b.args,...(name==='overdue'?[stamp]:[])])));
 const summary=Object.fromEntries(counters.map(([name])=>[name,counts.reduce((sum,row)=>sum+row[name],0)]));
 const upcoming=await rows(branches.map(b=>`SELECT * FROM (SELECT ${taskColumns} FROM tasks t WHERE ${b.sql} AND t.status IN ('pending','progress','returned') ORDER BY t.due,t.id LIMIT 4)`).join(' UNION ALL ')+' ORDER BY due,id LIMIT 4',...roleArgs);
 const team=await rows('SELECT assignee,COUNT(*) n FROM ('+related+") WHERE status IN ('pending','progress','returned','submitted') GROUP BY assignee",...roleArgs);return {...summary,upcoming,team};}
