// Calculate only aggregate connection quality; never collect media or participant identifiers.
export type QualitySample={received:number;lost:number};
export type CallQuality='checking'|'good'|'unstable';
type CallStat=RTCStats & {isRemote?:boolean;kind?:string;mediaType?:string;packetsReceived?:number;packetsLost?:number;jitter?:number;state?:string;nominated?:boolean;currentRoundTripTime?:number};
export function assessCallQuality(reports:Iterable<CallStat>,previous?:QualitySample):{quality:CallQuality;sample?:QualitySample}{
 let received=0,lost=0,hasPackets=false,worstJitter=0,worstRtt=0;
 for(const stat of reports){
  if(stat.type==='inbound-rtp'&&!stat.isRemote&&(stat.kind==='audio'||stat.kind==='video'||stat.mediaType==='audio'||stat.mediaType==='video')){
   if(typeof stat.packetsReceived==='number'&&Number.isFinite(stat.packetsReceived)&&typeof stat.packetsLost==='number'&&Number.isFinite(stat.packetsLost)){received+=Math.max(0,stat.packetsReceived);lost+=Math.max(0,stat.packetsLost);hasPackets=true}
   if(typeof stat.jitter==='number'&&Number.isFinite(stat.jitter))worstJitter=Math.max(worstJitter,stat.jitter);
  }
  if(stat.type==='candidate-pair'&&stat.state==='succeeded'&&stat.nominated&&typeof stat.currentRoundTripTime==='number'&&Number.isFinite(stat.currentRoundTripTime))worstRtt=Math.max(worstRtt,stat.currentRoundTripTime);
 }
 const sample=hasPackets?{received,lost}:undefined;
 if(!sample||!previous||sample.received<previous.received||sample.lost<previous.lost)return {quality:'checking',sample};
 const count=sample.received-previous.received,missing=sample.lost-previous.lost,total=count+missing;
 if(total<20)return {quality:'checking',sample};
 return {quality:missing/total>0.02||worstJitter>0.04||worstRtt>0.3?'unstable':'good',sample};
}
