// Compare optimised SQL against the straightforward access-filtered reference.
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {spawn} from 'node:child_process';
import {mkdtempSync,copyFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomBytes,createHash} from 'node:crypto';
const dir=mkdtempSync(join(tmpdir(),'activitytab-listing-check-')),origin='http://127.0.0.1:3210';
let db,child,log='',checks=0;
try{
 copyFileSync('work/performance-fixture.sqlite',join(dir,'activitytab.sqlite'));
 db=new DatabaseSync(join(dir,'activitytab.sqlite'));
 const admin=db.prepare("SELECT id FROM members WHERE role='admin'").get().id;
 const users=[admin,'employee-0','employee-1','employee-298'];
 db.exec('BEGIN');
 const stamp=new Date(Date.now()-86400000).toISOString();
 for(const [i,status]of ['pending','progress','returned','submitted','completed','cancelled'].entries()){
  db.prepare('INSERT INTO tasks(id,title,description,assignee,creator,due,status,frequency,priority,required,approval,created,escalation_manager,escalated_at) VALUES(?,?,?,?,?,?,?,\'once\',\'low\',0,1,?,?,?)').run('listing-'+i,'Listing edge '+i,'Full description','employee-0',i%2?admin:'employee-0',stamp,status,stamp,'employee-1',i===0?null:stamp);
  db.prepare("INSERT INTO documents(id,task,name,type,size,uploader,created) VALUES(?,?,?,'application/pdf',1,?,?)").run('listing-doc-'+i,'listing-'+i,'Regional edge '+i+'.pdf',admin,stamp);
 }
 const access='(t.assignee=? OR t.creator=? OR (t.escalation_manager=? AND t.escalated_at IS NOT NULL))';
 const cases=[];
 for(const user of users){
  const raw=randomBytes(32).toString('hex');db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(createHash('sha256').update(raw).digest('hex'),user,Date.now()+3600000);
  const summary=db.prepare(`SELECT COUNT(*) total,COALESCE(SUM(status='completed'),0) completed,COALESCE(SUM(status='cancelled'),0) cancelled,COALESCE(SUM(status='progress'),0) progress,COALESCE(SUM(status='submitted'),0) review,COALESCE(SUM(status NOT IN ('completed','cancelled')),0) active,COALESCE(SUM(status IN ('pending','progress','returned') AND due<?),0) overdue FROM tasks t WHERE ${access}`).get(new Date().toISOString(),user,user,user);
  const queries=['','Regional','Regional 12','999999999','!!!'];
  for(const search of queries){
   const tokens=search.match(/[\p{L}\p{N}_]+/gu)||[],match=tokens.map(t=>'"'+t+'"*').join(' AND '),filter=search?(match?' AND d.rowid IN (SELECT rowid FROM document_search WHERE document_search MATCH ?)':' AND 0'):'';
   const args=[user,user,user,...(match?[match]:[])],from=`FROM documents d JOIN tasks t ON t.id=d.task WHERE ${access}${filter}`;
   const total=db.prepare('SELECT COUNT(*) n '+from).get(...args).n;
   const ids=db.prepare('SELECT d.id '+from+' ORDER BY d.created DESC,d.id DESC LIMIT 200').all(...args).map(x=>x.id);
   cases.push({user,search,cookie:'activitytab_session='+raw,summary,total,ids});
  }
 }
 db.exec('COMMIT');db.close();db=null;
 child=spawn(process.execPath,['windows/dist/server.mjs'],{env:{...process.env,PORT:'3210',ACTIVITYTAB_DATA:dir,ACTIVITYTAB_ORIGIN:origin,ACTIVITYTAB_DEV:'1'},stdio:['ignore','pipe','pipe']});
 child.stdout.on('data',d=>log+=d);child.stderr.on('data',d=>log+=d);
 await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(Error(log)),15000);child.once('exit',()=>{clearTimeout(t);reject(Error(log))});child.stdout.on('data',()=>{if(log.includes('listening')){clearTimeout(t);resolve()}})});
 async function get(path,cookie){const r=await fetch(origin+'/ActivityTAB/api/'+path,{headers:{Cookie:cookie},signal:AbortSignal.timeout(10000)});assert.equal(r.status,200);return r.json()}
 for(const c of cases){
  const p=await get('documents?q='+encodeURIComponent(c.search),c.cookie);assert.equal(p.total,c.total);assert.deepEqual(p.documents.map(d=>d.id),c.ids.slice(0,100));checks++;
  if(p.next){const next=await get('documents?q='+encodeURIComponent(c.search)+'&cursor='+encodeURIComponent(p.next),c.cookie);assert.deepEqual(next.documents.map(d=>d.id),c.ids.slice(100,200));checks++}
  if(!c.search){const state=await get('state?lean=1',c.cookie);for(const [key,value]of Object.entries(c.summary))assert.equal(state.summary[key],value,key+' for '+c.user);checks++}
 }
 console.log(JSON.stringify({ok:true,checks,coverage:'Large and small access scopes; shared creator/assignee; granted and ungranted escalations; all statuses; exact dashboard totals; broad, selective, empty and punctuation searches; first and second document pages.'}));
}finally{db?.close();if(child&&child.exitCode===null){child.kill();await new Promise(r=>child.once('exit',r))}rmSync(dir,{recursive:true,force:true})}
