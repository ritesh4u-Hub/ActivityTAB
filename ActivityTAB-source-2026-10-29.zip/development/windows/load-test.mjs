// Isolated HTTP capacity test. Never accepts a remote target or production data.
// First create synthetic history with ACTIVITYTAB_KEEP_LOAD=1 node windows/performance-test.mjs.
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {spawn} from 'node:child_process';
import {mkdtempSync,copyFileSync,rmSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomBytes,createHash,randomUUID} from 'node:crypto';
import {setTimeout as sleep} from 'node:timers/promises';
import {monitorEventLoopDelay} from 'node:perf_hooks';

const label=process.argv[2]||'local',duration=Number(process.env.LOAD_STAGE_SECONDS||20);
assert.ok(/^[a-z0-9-]+$/.test(label)&&duration>=5&&duration<=60);
const dir=mkdtempSync(join(tmpdir(),'activitytab-capacity-')),origin='http://127.0.0.1:3208',base=origin+'/ActivityTAB/api/';
let child,db,logs='',inflight=0,maxInflight=0;const pending=new Set(),results=[],failures=[];
const sha=s=>createHash('sha256').update(s).digest('hex');
const percentile=(a,p)=>a.length?a.slice().sort((a,b)=>a-b)[Math.min(a.length-1,Math.ceil(a.length*p)-1)]:0;
try{
 copyFileSync('work/performance-fixture.sqlite',join(dir,'activitytab.sqlite'));
 db=new DatabaseSync(join(dir,'activitytab.sqlite'));db.exec('PRAGMA journal_mode=WAL; BEGIN');
 assert.equal(db.prepare('SELECT COUNT(*) n FROM members').get().n,300,'Synthetic 300-employee fixture required');
 assert.equal(db.prepare('SELECT COUNT(*) n FROM subscriptions').get().n,0,'No real push subscriptions allowed');
 const people=db.prepare("SELECT id,role FROM members ORDER BY role='admin' DESC,id").all();
 const accounts=people.map(p=>{const token=randomBytes(32).toString('hex');db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(sha(token),p.id,Date.now()+3600000);return {...p,cookie:'activitytab_session='+token,session:randomUUID()}});
 // Explicitly disable reminder work on this fixture; scheduler cost is measured separately.
 db.prepare("UPDATE settings SET value=? WHERE key='reminders'").run(JSON.stringify({workStart:0,workEnd:0,beforeHours:24,repeatHours:24,escalateHours:48}));
 const stamp=new Date().toISOString(),start=new Date(Date.now()-60000).toISOString(),end=new Date(Date.now()+3600000).toISOString();
 const meeting=db.prepare("INSERT INTO meetings(id,title,kind,owner,host,start,end,reminder,created,updated) VALUES(?,?,'online',?,?,?,?,0,?,?)");
 const membership=db.prepare('INSERT INTO meeting_members VALUES(?,?)');
 for(let i=0;i<10000;i++){
  const owner=accounts[i%300].id,when=new Date(Date.now()-(i+1)*86400000).toISOString();
  meeting.run('history-'+i,'Historical fixture meeting',owner,owner,when,when,stamp,stamp);membership.run('history-'+i,owner);
 }
 for(let g=0;g<4;g++){
  const id='load-call-'+g,owner=accounts[g*8].id;meeting.run(id,'Capacity test call',owner,owner,start,end,stamp,stamp);
  for(let n=0;n<8;n++){const a=accounts[g*8+n];a.meeting=id;membership.run(id,a.id)}
 }
 const activeTask=db.prepare("SELECT id FROM tasks WHERE assignee=? AND status='pending' LIMIT 1");
 for(const a of accounts){a.task=activeTask.get(a.id)?.id;db.prepare("INSERT OR IGNORE INTO chat_members(conversation,member) VALUES('large-chat',?)").run(a.id)}
 const fixture={employees:300,tasks:db.prepare('SELECT COUNT(*) n FROM tasks').get().n,documents:db.prepare('SELECT COUNT(*) n FROM documents').get().n,messages:db.prepare('SELECT COUNT(*) n FROM chat_messages').get().n,notifications:db.prepare('SELECT COUNT(*) n FROM notifications').get().n,meetings:10004,simultaneousCallParticipants:32};
 db.exec('COMMIT; PRAGMA optimize');db.close();db=null;
 child=spawn(process.execPath,[join(process.env.LOAD_SERVER_DIR||'windows/dist','server.mjs')],{env:{...process.env,PORT:'3208',ACTIVITYTAB_DATA:dir,ACTIVITYTAB_ORIGIN:origin,ACTIVITYTAB_DEV:'1'},stdio:['ignore','pipe','pipe']});
 child.stdout.on('data',d=>logs+=d);child.stderr.on('data',d=>logs+=d);
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Isolated startup failed: '+logs)),15000);child.once('exit',()=>{clearTimeout(timer);reject(Error(logs))});child.stdout.on('data',()=>{if(logs.includes('listening')){clearTimeout(timer);resolve()}})});
 async function request(a,path,method='GET',body,stage='setup',kind=path.split('?')[0]){
  const t=performance.now();inflight++;maxInflight=Math.max(maxInflight,inflight);
  try{
   const response=await fetch(base+path,{method,headers:{Cookie:a.cookie,Origin:origin,...(body&&!(body instanceof FormData)?{'Content-Type':'application/json'}:{})},body:body instanceof FormData?body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(10000)});
   const text=await response.text();if(stage!=='setup')results.push({stage,kind,ms:performance.now()-t,status:response.status,bytes:Buffer.byteLength(text)});
   if(response.status!==200){if(failures.length<20)failures.push({stage,kind,status:response.status,body:text.slice(0,120)})}
   return {status:response.status,data:JSON.parse(text)};
  }catch(e){if(stage!=='setup')results.push({stage,kind,ms:performance.now()-t,status:0,bytes:0});if(failures.length<20)failures.push({stage,kind,error:e.message});return {status:0}}
  finally{inflight--}
 }
 for(const a of accounts.slice(0,32))assert.equal((await request(a,'meetings/'+a.meeting+'/presence','POST',{session:a.session})).status,200);
 const probes=[];
 for(const a of accounts.slice(0,2))for(const path of ['state?lean=1','tasks?status=all','documents?q=Regional','chat/large-chat/messages','meetings?scope=upcoming']){
  const samples=[];for(let n=0;n<3;n++){const t=performance.now();assert.equal((await request(a,path)).status,200);samples.push(performance.now()-t)}
  probes.push({role:a.role,path,p95ms:Math.round(percentile(samples,.95))});
 }
 const stageDelivery=[];
 const stages=[{name:'expected-300-users',rps:35},{name:'burst-headroom',rps:75}];
 for(const stage of stages){
  let sequence=0,dropped=0,heartbeats=0,callPolls=0;const begun=performance.now(),until=begun+duration*1000;
  const clientDelay=monitorEventLoopDelay({resolution:10});clientDelay.enable();const arrivalLag=[];
  const launch=p=>{pending.add(p);p.finally(()=>pending.delete(p))};
  const heartbeat=setInterval(()=>{const a=accounts[heartbeats++%32];launch(request(a,'meetings/'+a.meeting+'/presence','POST',{session:a.session},stage.name,'call-heartbeat'))},125);
  // Thirty-two callers each perform live + signal polling every two seconds.
  // Stagger them rather than generating an unrealistic synchronised timer burst.
  const callPolling=setInterval(()=>{const a=accounts[callPolls++%32];if(inflight>=100){dropped+=2;return}launch((async()=>{await request(a,'meetings/'+a.meeting+'/live','GET',undefined,stage.name,'call-live');await request(a,'meetings/'+a.meeting+'/signals?session='+a.session+'&after=0','GET',undefined,stage.name,'call-signals')})())},62.5);
  while(performance.now()<until){
   const due=begun+sequence*1000/stage.rps;if(due>performance.now())await sleep(due-performance.now());
   arrivalLag.push(Math.max(0,performance.now()-due));
   const index=sequence++,a=accounts[(index*17)%300],slot=index%20;
   // Do not create a huge client queue and mistake queued work for capacity.
   if(inflight>=100){dropped++;continue}
   let path,method='GET',body,kind;
   if(slot<4)path='state?lean=1';
   else if(slot<7)path='tasks?status=all';
   else if(slot===7)path='tasks?q=Quarterly%2091234';
   else if(slot<10)path='documents?q=Regional';
   else if(slot<12)path='notifications';
   else if(slot<14)path='chat?paged=1';
   else if(slot<16)path='chat/large-chat/messages';
   else if(slot===16)path='meetings?scope=upcoming';
   else if(slot===17)path='availability?member='+encodeURIComponent(a.id)+'&day='+new Date().toISOString().slice(0,10);
   else if(slot===18){const c=accounts[index%32];launch(request(c,'meetings/'+c.meeting+'/live','GET',undefined,stage.name,'call-live'));continue}
   else if(a.task){path='tasks/'+a.task;method='PATCH';body={action:'acknowledge'};kind='task-write'}else path='tasks?status=all';
   launch(request(a,path,method,body,stage.name,kind));
  }
  clearInterval(heartbeat);clearInterval(callPolling);await Promise.all([...pending]);
  clientDelay.disable();
  const delivery={stage:stage.name,offeredRps:stage.rps+40,scheduled:sequence,heartbeats,callPolls,dropped,elapsedMs:Math.round(performance.now()-begun),clientEventLoop:{p95ms:Math.round(clientDelay.percentile(95)/1e6),maxMs:Math.round(clientDelay.max/1e6)},arrivalLag:{p95ms:Math.round(percentile(arrivalLag,.95)),maxMs:Math.round(Math.max(...arrivalLag))}};stageDelivery.push(delivery);console.log(JSON.stringify(delivery));
 }
 const summary=stages.map(s=>{const samples=results.filter(r=>r.stage===s.name);return {stage:s.name,requests:samples.length,p50ms:Math.round(percentile(samples.map(x=>x.ms),.5)),p95ms:Math.round(percentile(samples.map(x=>x.ms),.95)),p99ms:Math.round(percentile(samples.map(x=>x.ms),.99)),maxMs:Math.round(Math.max(...samples.map(x=>x.ms))),errors:samples.filter(x=>x.status!==200).length,byRoute:Object.fromEntries([...new Set(samples.map(x=>x.kind))].map(k=>{const rows=samples.filter(x=>x.kind===k);return[k,{count:rows.length,p95ms:Math.round(percentile(rows.map(x=>x.ms),.95)),errors:rows.filter(x=>x.status!==200).length}]}))}});
 const metrics=await request(accounts[0],'performance');
 const report={label,at:new Date().toISOString(),fixture,durationSecondsPerStage:duration,maxInflight,probes,stageDelivery,summary,failures,server:metrics.data,limits:['Local synthetic workload, not the production Windows hardware or IIS/TLS path.','Call HTTP presence/live endpoints tested; real video bandwidth, TURN and device capture are not simulated.','Large document history includes metadata; physical 20 MB uploads are covered separately.']};
 writeFileSync('outputs/load-'+label+'.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
 assert.equal(results.filter(x=>x.status!==200).length,0,'No HTTP errors under the chosen load');
}finally{
 db?.close();if(child&&child.exitCode===null){child.kill();await Promise.race([new Promise(r=>child.once('exit',r)),sleep(5000)]);if(child.exitCode===null)child.kill('SIGKILL')}
 rmSync(dir,{recursive:true,force:true});
}
