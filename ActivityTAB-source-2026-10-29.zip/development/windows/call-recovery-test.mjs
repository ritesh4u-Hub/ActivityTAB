import assert from 'node:assert/strict';
import {readFileSync,realpathSync} from 'node:fs';
import {createRequire} from 'node:module';
import vm from 'node:vm';
const {transform}=createRequire(realpathSync('node_modules/wrangler/package.json'))('esbuild');
const page=readFileSync('app/page.tsx','utf8');
const refresh=page.slice(page.indexOf('async function refresh()'),page.indexOf('useEffect(()=>{const params='));
assert.ok(refresh.startsWith('async function refresh()'));
const {code:refreshCode}=await transform(refresh,{loader:'ts'});
for(let cycle=1;cycle<=3;cycle++){
 let failure=null,authError=null,connectionError='',state={me:{id:'self'}};
 const context={api:async()=>{if(failure)throw failure;return state},settingsDirty:{current:false},setState(v){state=v},setSettingsState(){},setAuthError(v){authError=v},setConnectionError(v){connectionError=v},setLoading(){}};
 vm.runInNewContext(refreshCode,context);
 for(const error of [Object.assign(Error('signal timed out'),{name:'TimeoutError'}),Error('Failed to fetch'),Object.assign(Error('Unavailable'),{status:503})]){
  failure=error;await context.refresh();assert.equal(authError,null,'Temporary request failure must never trigger the workspace access gate');assert.ok(connectionError);assert.equal(state.me.id,'self');
 }
 failure=null;await context.refresh();assert.equal(connectionError,'');
 failure=Object.assign(Error('Sign in required'),{status:401});await context.refresh();assert.equal(authError.status,401,'Real access loss still enforces sign-in');
}
let source=readFileSync('app/meeting-room.tsx','utf8');const end=source.indexOf(' return <div className="meeting-overlay');assert.ok(end>0);
source=source.slice(0,end)+' return {join,poll,heartbeat,send,flushSignals,live};\n}\n';
const {code}=await transform(source,{loader:'tsx',format:'cjs',jsx:'automatic'});
const stabilityModule={exports:{}};const stabilityCode=(await transform(readFileSync('lib/call-stability.ts','utf8'),{loader:'ts',format:'cjs'})).code;
vm.runInNewContext(stabilityCode,{module:stabilityModule,exports:stabilityModule.exports});
function fixture(){
 const tracks=['audio','video'].map(kind=>({kind,stopped:false,stop(){this.stopped=true}}));
 const stream={getTracks:()=>tracks,getVideoTracks:()=>tracks.filter(t=>t.kind==='video'),getAudioTracks:()=>tracks.filter(t=>t.kind==='audio')};
 const meeting={id:'meeting',host:'self',auto_record:0,recordings:[],members:['self']};
 let mode='',closed=0,delivered=0,rtc={iceServers:[]},rtcRequests=0;const timers=new Map();let id=0;
 const context={module:{exports:{}},exports:{},require(name){if(name==='react')return {useState:v=>[v,()=>{}],useRef:v=>({current:v}),useEffect(){}};if(name==='../lib/call-stability')return stabilityModule.exports;return {}},crypto:{randomUUID:()=> 'same-session'},navigator:{mediaDevices:{getUserMedia:async()=>stream}},setTimeout(fn,ms){const key=++id;timers.set(key,{fn,ms});return key},clearTimeout(key){timers.delete(key)},Date,console};context.exports=context.module.exports;
 vm.runInNewContext(code,context);
 const api=async(path,method)=>{
  if(path.endsWith('/rtc')){rtcRequests++;return rtc}
  if(path.endsWith('/live')){if(mode==='live-timeout')throw Error('signal timed out');if(mode==='forbidden')throw Object.assign(Error('No longer invited'),{status:403});return {...meeting,presence:mode==='missing'?[]:[{member:'self',session:'same-session'}]}}
  if(path.includes('/signals?')){if(mode==='signals-timeout')throw Error('signal timed out');if(mode==='expired')throw Object.assign(Error('Call session expired'),{status:409});return {signals:[]}}
  if(path.endsWith('/signals')&&method==='POST'){if(mode==='send-timeout')throw Error('signal timed out');delivered++;return {ok:true}}
  return {ok:true};
 };
 const room=context.module.exports.default({meeting,me:{id:'self',name:'Self'},members:[],api,apiBase:'/api/',onClose(){closed++},onMessage(){}});
 return {room,tracks,timers,setMode(v){mode=v},setRtc(v){rtc=v},rtcRequests:()=>rtcRequests,closed:()=>closed,delivered:()=>delivered};
}
const f=fixture();await f.room.join();
for(let cycle=1;cycle<=3;cycle++){
 const screen={stopped:false,stop(){this.stopped=true}};f.room.live.current.display={getTracks:()=>[screen]};
 for(const mode of ['live-timeout','signals-timeout','expired','missing']){
  f.setMode(mode);await f.room.poll();assert.equal(f.room.live.current.joined,true,mode+' must retain the call');assert.equal(f.closed(),0);assert.ok(f.tracks.every(t=>!t.stopped));assert.equal(screen.stopped,false,'Transient failure preserves screen capture');
 }
 f.setMode('send-timeout');await f.room.send('other','peer-session',{type:'ice',candidate:{candidate:'fixture'}});assert.equal(f.room.live.current.outbox.length,1,'Undelivered signal is retained');
 f.setMode('');await f.room.heartbeat();await f.room.poll();assert.equal(f.room.live.current.outbox.length,0);assert.equal(f.delivered(),cycle);assert.ok([...f.timers.values()].some(t=>t.ms===4000),'Independent heartbeat remains scheduled');
}
for(let cycle=1;cycle<=3;cycle++){
 const peer={session:'remote-session',pc:{connectionState:'connected',close(){throw Error('A missing heartbeat must not close a working media path')}}};
 f.room.live.current.peers.set('other',peer);await f.room.poll();await f.room.poll();assert.ok(f.room.live.current.peers.has('other'));f.room.live.current.peers.delete('other');
 // The RTC endpoint cannot extend credentials capped to meeting end. Repeated
 // live polls must not mark established peers for ICE restart or refetch every poll.
 const calls=fixture();await calls.room.join();const state=calls.room.live.current;
 state.rtc={iceServers:[],relayConfigured:true,expiresAt:Date.now()+300000};calls.setRtc(state.rtc);
 const established={session:'remote',pc:{connectionState:'connected',close(){throw Error('Unexpected peer teardown')},setConfiguration(){throw Error('Unchanged capped credentials need no reconfiguration')}}};
 state.peers.set('other',established);
 await calls.room.poll();await calls.room.poll();await calls.room.poll();
 assert.equal(established.refreshNeeded,undefined,'Credential refresh must not request a working-connection restart');
 assert.equal(calls.rtcRequests(),2,'Only one refresh after initial join across repeated polls');
 assert.ok(state.relayRefreshAfter>Date.now(),'Capped credential refresh is throttled');
 assert.equal(stabilityModule.exports.absentPeerExpired({session:'old'},[{member:'other',session:'replacement'}],'other',100),true,'A replaced session remains authoritative');
 const entry={session:'same'};assert.equal(stabilityModule.exports.absentPeerExpired(entry,[],'other',100),false);assert.equal(stabilityModule.exports.absentPeerExpired(entry,[],'other',90100),true);
}
f.setMode('forbidden');await f.room.poll();assert.equal(f.closed(),1,'Real access revocation ends call');assert.ok(f.tracks.every(t=>t.stopped));assert.equal(f.room.live.current.closed,true);
console.log('PASS: three workspace-refresh and MeetingRoom timeout-recovery cycles; three missing-peer and capped-credential refresh cycles; working peer media is retained during brief presence gaps; repeated credential polling never requests ICE restart; signals retry; expired grace and replacement sessions are enforced; real access revocation ends the call. Network/media APIs mocked; not a physical remote-device test.');
