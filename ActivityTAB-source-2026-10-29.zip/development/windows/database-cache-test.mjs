import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
const dir=mkdtempSync(join(tmpdir(),'activitytab-cache-test-'));
process.env.ACTIVITYTAB_DATA=dir;process.env.ACTIVITYTAB_SQL_PROFILE='1';
const {sqlite,env}=await import('./src/env.mjs');
const {databaseStatus,closeDatabase,withDatabasePriority}=await import('./src/database-client.mjs');
try{
 sqlite.exec('CREATE TABLE fixture(id INTEGER PRIMARY KEY,value TEXT);');

 const statement=(sql,...args)=>env.DB.prepare(sql).bind(...args);
 for(let i=0;i<50;i++)await statement('INSERT INTO fixture VALUES(?,?)',i,'employee-'+i).run();
 assert.equal((await databaseStatus()).prepares,1,'Repeated writes reuse the compiled SQL, not the bound values');
 const rows=await Promise.all(Array.from({length:50},(_,i)=>statement('SELECT value FROM fixture WHERE id=?',i).first()));
 assert.deepEqual(rows.map(r=>r.value),Array.from({length:50},(_,i)=>'employee-'+i));
 const stable=(await databaseStatus()).prepares;await statement('SELECT value FROM fixture WHERE id=?',12).first();assert.equal((await databaseStatus()).prepares,stable);
 await statement('SELECT * FROM fixture WHERE id=?',12).first();sqlite.exec('ALTER TABLE fixture ADD COLUMN note TEXT');
 await statement('UPDATE fixture SET note=? WHERE id=?','after schema change',12).run();
 assert.equal((await statement('SELECT * FROM fixture WHERE id=?',12).first()).note,'after schema change');
 await assert.rejects(env.DB.batch([statement('UPDATE fixture SET value=? WHERE id=?','must rollback',0),statement('INSERT INTO fixture(id,value) VALUES(?,?)',1,'duplicate')]));
 assert.equal((await statement('SELECT value FROM fixture WHERE id=?',0).first()).value,'employee-0');
 for(let i=0;i<160;i++)await statement('SELECT '+i+' n').first();
 const prior=(await databaseStatus()).prepares;await statement('SELECT value FROM fixture WHERE id=?',0).first();assert.equal((await databaseStatus()).prepares,prior+1,'Old statements are evicted instead of growing without bound');
 assert.ok((await databaseStatus()).sqlProfile.every(r=>!r.query.includes('employee-')&&!r.query.includes('must rollback')),'Diagnostic profiles never include bound data');
 assert.ok((await databaseStatus()).sqlProfile.length<=128,'Diagnostic memory is bounded');
 const completion=[];const queue=Array.from({length:24},(_,i)=>statement('SELECT ? n',i).first().then(()=>completion.push('normal-'+i)));
 const urgent=withDatabasePriority('call',()=>statement('SELECT ? n',99).first().then(()=>completion.push('call')));await Promise.all([...queue,urgent]);assert.ok(completion.indexOf('call')<8,'Call-control work must overtake queued archive reads');
 let heartbeatRan=false;const timer=setTimeout(()=>{heartbeatRan=true},10);
 await statement('WITH RECURSIVE n(x) AS (VALUES(1) UNION ALL SELECT x+1 FROM n WHERE x<1000000) SELECT SUM(x) n FROM n').first();
 clearTimeout(timer);assert.ok(heartbeatRan,'Expensive SQL must not block main-thread heartbeat timers');
 await closeDatabase();assert.equal((await statement('SELECT value FROM fixture WHERE id=?',0).first()).value,'employee-0','A subsequent request starts a new worker after shutdown without replaying failed writes');
 console.log('PASS: compiled-query reuse, independent concurrent parameters, bounded eviction, cached schema recompilation, rollback, call-priority scheduling, main-thread responsiveness during expensive SQL, worker replacement and parameter-free profiling.');
}finally{await closeDatabase();sqlite.close();rmSync(dir,{recursive:true,force:true})}
