import {Worker} from 'node:worker_threads';
import {AsyncLocalStorage} from 'node:async_hooks';
const key=Symbol.for('activitytab.database-client');
const contextKey=Symbol.for('activitytab.database-priority');
const context=globalThis[contextKey]??=(new AsyncLocalStorage());
export function withDatabasePriority(priority,action){return context.run(priority,action)}
// One shared worker per server process, including bundled API/scheduler modules.
// Short call-control queries go ahead of queued archive queries. Limit a streak
// to eight so ordinary task operations still make progress during busy calls.
function create(dataDir){
 const worker=new Worker(new URL('./database-worker.mjs',import.meta.url),{workerData:{dataDir}}),urgent=[],normal=[];
 let current=null,sequence=0,urgentStreak=0,dead=false,completed=0;
 const pump=()=>{if(dead||current)return;if(!urgent.length&&!normal.length){worker.unref();return}current=urgent.length&&(urgentStreak<8||!normal.length)?(urgentStreak++,urgent.shift()):(urgentStreak=0,normal.shift());worker.ref();worker.postMessage(current.message)};
 const fail=()=>{if(dead)return;dead=true;const error=Object.assign(Error('Database worker is unavailable. Please try again.'),{status:503});current?.reject(error);current=null;for(const job of [...urgent,...normal])job.reject(error);urgent.length=normal.length=0;if(globalThis[key]===client)delete globalThis[key]};
 worker.on('error',fail);worker.on('exit',fail);
 worker.on('message',response=>{if(!current||current.message.id!==response.id)return;const job=current;current=null;completed++;if(response.error){const error=Object.assign(Error(response.error.message),{code:response.error.code});job.reject(error)}else job.resolve(response.result);pump()});
 worker.unref();
 function request(method,payload={}){if(dead)return Promise.reject(Object.assign(Error('Database worker is unavailable. Please try again.'),{status:503}));if(urgent.length+normal.length>=512)return Promise.reject(Object.assign(Error('The server is busy. Please retry shortly.'),{status:503}));const priority=context.getStore()==='call'||(method!=='batch'&&/\bmeeting_(presence|signals)\b/i.test(payload.sql||''));return new Promise((resolve,reject)=>{(priority?urgent:normal).push({message:{id:++sequence,method,...payload},resolve,reject});pump()})}
 const client={dataDir,request,status:()=>({worker:true,queued:urgent.length+normal.length,urgent:urgent.length,busy:!!current,completed}),async close(){dead=true;const error=Error('Database closed');current?.reject(error);current=null;for(const job of [...urgent,...normal])job.reject(error);urgent.length=normal.length=0;await worker.terminate();if(globalThis[key]===client)delete globalThis[key]}};
 return client;
}
export function databaseClient(dataDir){const current=globalThis[key];if(current){if(current.dataDir!==dataDir)throw Error('Conflicting database directory');return current}return globalThis[key]=create(dataDir)}
export async function databaseStatus(){const client=globalThis[key];return client?{...client.status(),...await client.request('stats')}:null}
export async function closeDatabase(){await globalThis[key]?.close()}
