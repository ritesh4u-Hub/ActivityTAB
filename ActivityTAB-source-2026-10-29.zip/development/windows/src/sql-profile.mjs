// Opt-in diagnostics for isolated capacity tests. Parameters are never recorded.
const enabled=process.env.ACTIVITYTAB_SQL_PROFILE==='1';
const key=Symbol.for('activitytab.sql-profile');
const groups=enabled?(globalThis[key]??=(new Map())):null;
export function profileDatabase(database,label){
 if(!enabled)return;
 const original=database.prepare.bind(database);
 database.prepare=function(sql){
  const statement=original(sql);
  return new Proxy(statement,{get(target,property){
   const value=Reflect.get(target,property,target);
   if(typeof value!=='function')return value;
   if(!['all','get','run'].includes(property))return value.bind(target);
   return function(...args){const start=performance.now();try{return Reflect.apply(value,target,args)}finally{
    const fingerprint=label+' '+sql.replace(/\s+/g,' ').slice(0,1200);
    let group=groups.get(fingerprint);if(!group&&groups.size<128){group={count:0,totalMs:0,maxMs:0};groups.set(fingerprint,group)}
    if(group){const ms=performance.now()-start;group.count++;group.totalMs+=ms;group.maxMs=Math.max(group.maxMs,ms)}
   }};
  }});
 };
}
export function sqlProfile(){return groups?[...groups].map(([query,g])=>({query,count:g.count,totalMs:Math.round(g.totalMs),maxMs:Math.round(g.maxMs)})).sort((a,b)=>b.totalMs-a.totalMs):undefined}
