import {parentPort,workerData} from 'node:worker_threads';
import {DatabaseSync} from 'node:sqlite';
import {join} from 'node:path';
import {profileDatabase,sqlProfile} from './sql-profile.mjs';
const database=new DatabaseSync(join(workerData.dataDir,'activitytab.sqlite'));
database.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; PRAGMA cache_size=-16384;');
profileDatabase(database,'database-worker');
const cache=new Map();let prepares=0;
function prepare(sql){let st=cache.get(sql);if(st){cache.delete(sql);cache.set(sql,st);return st}st=database.prepare(sql);prepares++;cache.set(sql,st);if(cache.size>128)cache.delete(cache.keys().next().value);return st}
parentPort.on('message',message=>{
 try{
  const {id,method,sql,args,statements}=message;let result;
  if(method==='stats')result={preparedEntries:cache.size,prepares,sqlProfile:sqlProfile()};
  else if(method==='batch'){
   database.exec('BEGIN IMMEDIATE');
   try{result=statements.map(s=>({meta:{changes:Number(prepare(s.sql).run(...s.args).changes)}}));database.exec('COMMIT')}
   catch(error){database.exec('ROLLBACK');throw error}
  }else if(method==='all')result={results:prepare(sql).all(...args)};
  else if(method==='first')result=prepare(sql).get(...args)||null;
  else if(method==='run')result={meta:{changes:Number(prepare(sql).run(...args).changes)}};
  else throw Error('Unsupported database operation');
  parentPort.postMessage({id,result});
 }catch(error){parentPort.postMessage({id:message.id,error:{message:error.message,code:error.code}})}
});
