import {DatabaseSync} from 'node:sqlite';
import {mkdirSync,existsSync,createReadStream} from 'node:fs';
import {writeFile,rm} from 'node:fs/promises';
import {Readable} from 'node:stream';
import {join,dirname} from 'node:path';
import {profileDatabase} from './sql-profile.mjs';
import {databaseClient} from './database-client.mjs';
export const dataDir=process.env.ACTIVITYTAB_DATA || join(dirname(process.argv[1]),'data');
mkdirSync(join(dataDir,'uploads'),{recursive:true});
export const sqlite=new DatabaseSync(join(dataDir,'activitytab.sqlite'));
// Give large task/FTS indexes a 16 MB page-cache target per connection instead
// of the default ~2 MB; preserve the existing synchronous durability policy.
sqlite.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; PRAGMA cache_size=-16384;');
profileDatabase(sqlite,import.meta.url.split('/').at(-1));
const client=()=>databaseClient(dataDir);
export const env={RTC:{urls:(process.env.ACTIVITYTAB_TURN_URLS||'').split(',').filter(Boolean),secret:process.env.ACTIVITYTAB_TURN_SECRET||''},DB:{batch(statements){return client().request('batch',{statements:statements.map(({sql,args})=>({sql,args}))})},prepare(sql){return {bind(...args){return {sql,args,all(){return client().request('all',{sql,args})},first(){return client().request('first',{sql,args})},run(){return client().request('run',{sql,args})}}}}}},BUCKET:{async delete(id){if(!/^[\w-]+$/.test(id))throw Error('Invalid file id');await rm(join(dataDir,'uploads',id),{force:true})},async put(id,bytes){if(!/^[\w-]+$/.test(id))throw Error('Invalid file id');await writeFile(join(dataDir,'uploads',id),Buffer.from(bytes))},async get(id){if(!/^[\w-]+$/.test(id))return null;const p=join(dataDir,'uploads',id);return existsSync(p)?{body:Readable.toWeb(createReadStream(p))}:null}}};
