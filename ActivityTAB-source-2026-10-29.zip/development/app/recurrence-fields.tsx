'use client';
import {useState} from 'react';
export default function RecurrenceFields({initial='once'}:{initial?:string}){
 const [frequency,setFrequency]=useState(initial),[date,setDate]=useState(''),[dates,setDates]=useState<string[]>([]);
 return <><label>Repeat<select name="frequency" value={frequency} onChange={e=>setFrequency(e.target.value)}><option value="once">One-time task</option><option value="daily">Daily</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option><option value="interval">Every N days</option><option value="dates">Specific dates</option></select></label>
 {frequency==='interval'&&<label>Repeat every (calendar days)<input name="interval" type="number" min="2" max="365" step="1" defaultValue="3" required/><small>For example, enter 3 for every three calendar days.</small></label>}
 {frequency==='dates'&&<div><label>Additional date<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label><button type="button" className="button" disabled={!date||dates.length>=100} onClick={()=>{if(date&&!dates.includes(date))setDates([...dates,date].sort());setDate('')}}>Add date</button><p className="small-muted">The deadline above is the first occurrence. Add up to 100 later dates; each uses the same deadline time (IST).</p>{dates.map(d=><div key={d}>{d} <button className="text-button" type="button" onClick={()=>setDates(dates.filter(x=>x!==d))} aria-label={'Remove '+d}>Remove</button></div>)}<input type="hidden" name="dates" value={JSON.stringify(dates)}/></div>}</>;
}
