ActivityTAB source backup — 29 October 2026

production-compatible/ contains the source used for release 2026.10.28.4, including task groups, editing and repeat schedules. Some unused guest-related source files and migration 0007 may be present but are not part of that published release. This is a source backup, not a deployment package.

development/ contains the working development source, including unpublished guest meeting and call quality work. It should not be deployed without review and testing.

Runtime configuration, credentials, databases, uploaded documents, recordings, dependencies and generated builds are excluded. This archive is not a backup of employee data.
