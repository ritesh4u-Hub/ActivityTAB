ActivityTAB source backup — 30 October 2026

production-compatible/ contains the source used for release 2026.10.29.1, including multi-person task assignment, editing document requirements and screen capture safeguards. This is a source backup, not a deployment package.

development/ contains working source including unpublished development work. Review and test it before deployment.

Runtime configuration, credentials, databases, uploads, recordings, dependencies and generated builds are excluded. This is not a backup of employee data.
