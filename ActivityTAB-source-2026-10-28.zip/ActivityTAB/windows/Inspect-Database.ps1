$ErrorActionPreference='Stop'
# Inventory only: no credentials, application rows, or connection strings are read.
$services=@(Get-Service | Where-Object {$_.Name -eq 'MSSQLSERVER' -or $_.Name -like 'MSSQL$*'} | Select-Object Name,Status)
$instances=@()
foreach($path in @('HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Microsoft SQL Server\Instance Names\SQL')){
 if(Test-Path $path){$item=Get-ItemProperty $path;foreach($property in $item.PSObject.Properties){if($property.Name -notlike 'PS*'){$instances+=$property.Name}}}
}
$report=[ordered]@{checkedAt=(Get-Date).ToUniversalTime().ToString('o');computer=$env:COMPUTERNAME;sqlServices=$services;sqlInstances=@($instances|Select-Object -Unique);sqlcmdAvailable=[bool](Get-Command sqlcmd -ErrorAction SilentlyContinue);appHealth=$null}
try{$report.appHealth=Invoke-RestMethod 'http://127.0.0.1:3187/ActivityTAB/health'}catch{$report.appHealth='Unavailable'}
$output=$report|ConvertTo-Json -Depth 5
$output|Set-Content -Encoding UTF8 'C:\ProgramData\ActivityTAB\database-inventory.json'
try{$output|Set-Content -Encoding UTF8 '\\tsclient\server-transfer\ActivityTAB-database-inventory.json'}catch{Write-Host 'Report saved privately on server; redirected Mac folder is read-only.'}
Write-Host $output
Read-Host 'Inventory complete. Press Enter to close'
