import assert from 'node:assert/strict';import vm from 'node:vm';import{readFileSync,realpathSync}from'node:fs';import{createRequire}from'node:module';
const{transform}=createRequire(realpathSync('node_modules/wrangler/package.json'))('esbuild');
const source=readFileSync('app/meeting-room.tsx','utf8');const start=source.indexOf('function ParticipantAudio('),end=source.indexOf('export default function MeetingRoom');assert.ok(start>0&&end>start);
const{code}=await transform(source.slice(start,end),{loader:'tsx',format:'cjs',jsx:'automatic'});
let effect,blocked=false,rejectPlayback=false,plays=0,pauses=0;const element={srcObject:null,async play(){plays++;if(rejectPlayback)throw Error('Browser blocked autoplay')},pause(){pauses++}};
const context={useRef:()=>({current:element}),useState:()=>[blocked,v=>blocked=v],useEffect:fn=>effect=fn,require:()=>({jsx:(type,props)=>({type,props}),jsxs:(type,props)=>({type,props}),Fragment:'fragment'})};vm.runInNewContext(code,context);
for(let cycle=1;cycle<=3;cycle++){
 const stream={stop(){throw Error('Playback cleanup must never stop a shared media source')}};
 let view=context.ParticipantAudio({stream,name:'Participant'});assert.equal(view.props.children[0].type,'audio');assert.equal(view.props.children[0].props.muted,undefined,'Remote playback is audible');const cleanup=effect();await Promise.resolve();await Promise.resolve();assert.equal(element.srcObject,stream);assert.equal(blocked,false);
 rejectPlayback=true;cleanup();view=context.ParticipantAudio({stream,name:'Participant'});const cleanupBlocked=effect();await Promise.resolve();await Promise.resolve();assert.equal(blocked,true);view=context.ParticipantAudio({stream,name:'Participant'});rejectPlayback=false;await view.props.children[1].props.onClick();assert.equal(blocked,false,'User interaction recovers blocked audio playback');cleanupBlocked();assert.equal(element.srcObject,null);
}
assert.equal(plays,9);assert.equal(pauses,6);
console.log('PASS: three participant-audio lifecycles, audible remote playback, autoplay-rejection recovery and source-preserving cleanup. Browser audio APIs mocked; audibility on a physical receiver remains separate.');
