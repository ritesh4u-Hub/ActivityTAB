import {DatabaseSync} from 'node:sqlite';
import {readFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';

// Rehearses additive migrations on a stopped application's private database copy.
// Never use this file against a live database connection.
const [folder,dbFile,manifestFile]=process.argv.slice(2);
if(!folder||!dbFile||!manifestFile)throw Error('Expected staged folder, database copy, manifest');
const manifest=JSON.parse(readFileSync(manifestFile,'utf8'));
for(const [name,expected] of Object.entries(manifest.files)){
 if(name.includes('..')||name.startsWith('/')||name.includes('\\'))throw Error('Invalid package path');
 const file=join(folder,name);
 if(!existsSync(file)||createHash('sha256').update(readFileSync(file)).digest('hex')!==expected)throw Error('Package file verification failed: '+name);
}
const {migrate}=await import(pathToFileURL(join(folder,'migrate.mjs')));
const db=new DatabaseSync(dbFile);
try{
 if(db.prepare('PRAGMA quick_check').get().quick_check!=='ok')throw Error('Source database integrity check failed');
 const preserved=['members','tasks','documents','credentials','sessions','notifications','chat_messages'];
 const counts=()=>Object.fromEntries(preserved.map(table=>[table,db.prepare(`SELECT COUNT(*) AS n FROM ${table}`).get().n]));
 const before=counts();
 migrate(db,folder);
 if(db.prepare('PRAGMA quick_check').get().quick_check!=='ok')throw Error('Migrated database integrity check failed');
 const after=counts();
 for(const table of preserved)if(before[table]!==after[table])throw Error('Unexpected record count change: '+table);
 for(const table of ['meetings','meeting_members','meeting_recordings','retired_photos'])db.prepare(`SELECT COUNT(*) FROM ${table}`).get();
 console.log(JSON.stringify({ok:true,release:manifest.version,existingRecordsPreserved:true,schemaVersions:db.prepare('SELECT version FROM schema_migrations ORDER BY version').all().map(r=>r.version)}));
}finally{db.close()}
