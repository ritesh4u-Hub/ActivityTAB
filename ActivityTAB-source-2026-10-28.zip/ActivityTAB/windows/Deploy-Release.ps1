param([Parameter(Mandatory=$true)][string]$ExpectedZipHash)
$ErrorActionPreference='Stop'
$target='C:\inetpub\wwwroot\CFOProject\ActivityTAB'
$private='C:\ProgramData\ActivityTAB'
$share='\\tsclient\server-transfer'
$data=Join-Path $private 'data'
$node=Join-Path $private 'runtime\node-v24.22.1-win-x64\node.exe'
$stopped=$false;$changed=$false;$backup=$null;$poolWasRunning=$false
function Stop-App {
 Stop-ScheduledTask -TaskName 'ActivityTAB Server'
 Start-Sleep -Seconds 2
 $owned=@(Get-CimInstance Win32_Process|Where-Object{$_.Name -eq 'node.exe' -and $_.CommandLine -like ('*'+$target+'\server.mjs*')})
 foreach($process in $owned){Stop-Process -Id $process.ProcessId -ErrorAction SilentlyContinue}
 Start-Sleep -Seconds 1
 if(Get-CimInstance Win32_Process|Where-Object{$_.Name -eq 'node.exe' -and $_.CommandLine -like ('*'+$target+'\server.mjs*')}){throw 'ActivityTAB process is still running'}
}
try{
 Import-Module WebAdministration
 if(-not(Test-Path $node)){throw 'Existing Node runtime was not found'}
 if(-not(Test-Path (Join-Path $data 'activitytab.sqlite'))){throw 'Existing database was not found'}
 $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
 $stage=Join-Path $private ('packages\release-'+$stamp)
 New-Item -ItemType Directory -Path $stage -Force|Out-Null
 $zip=Join-Path $stage 'release.zip'
 Copy-Item -LiteralPath (Join-Path $share 'ActivityTAB-Windows-update.zip') -Destination $zip
 if((Get-FileHash $zip -Algorithm SHA256).Hash -ne $ExpectedZipHash){throw 'Release archive checksum failed'}
 $app=Join-Path $stage 'app'
 Expand-Archive -LiteralPath $zip -DestinationPath $app
 Copy-Item -LiteralPath (Join-Path $share 'ActivityTAB-release-manifest.json') -Destination $stage
 Copy-Item -LiteralPath (Join-Path $share 'ActivityTAB-verify-update.mjs') -Destination $stage
 $manifestFile=Join-Path $stage 'ActivityTAB-release-manifest.json'
 $manifest=Get-Content -Raw $manifestFile|ConvertFrom-Json
 foreach($property in $manifest.files.PSObject.Properties){
  if($property.Name -match '(^[\\/]|\.\.|:)'){throw 'Invalid manifest path'}
  if((Get-FileHash (Join-Path $app $property.Name) -Algorithm SHA256).Hash -ne $property.Value){throw ('Release file mismatch: '+$property.Name)}
 }
 $backup=Join-Path $private ('backups\meetings-performance-'+$stamp)
 New-Item -ItemType Directory -Path $backup -Force|Out-Null
 Copy-Item -LiteralPath $target -Destination (Join-Path $backup 'app') -Recurse
 $poolWasRunning=(Get-WebAppPoolState -Name 'ActivityTAB').Value -eq 'Started'
 if($poolWasRunning){Stop-WebAppPool -Name 'ActivityTAB'}
 $stopped=$true
 Stop-App
 $saved=Join-Path $backup 'data'
 New-Item -ItemType Directory -Path $saved|Out-Null
 Get-ChildItem -LiteralPath $data -Force|Where-Object{$_.Name -ne 'backups'}|ForEach-Object{Copy-Item -LiteralPath $_.FullName -Destination $saved -Recurse -Force}
 foreach($file in Get-ChildItem -LiteralPath $data -Force -File|Where-Object{$_.Name -like 'activitytab.sqlite*'}){
  if((Get-FileHash $file.FullName -Algorithm SHA256).Hash -ne (Get-FileHash (Join-Path $saved $file.Name) -Algorithm SHA256).Hash){throw 'Database backup verification failed'}
 }
 $rehearsal=Join-Path $stage 'database-rehearsal'
 New-Item -ItemType Directory -Path $rehearsal|Out-Null
 Get-ChildItem -LiteralPath $saved -File|Where-Object{$_.Name -like 'activitytab.sqlite*'}|ForEach-Object{Copy-Item $_.FullName $rehearsal}
 Write-Host 'Verifying package, database integrity and migrations on a private copy...'
 & $node (Join-Path $stage 'ActivityTAB-verify-update.mjs') $app (Join-Path $rehearsal 'activitytab.sqlite') $manifestFile
 if($LASTEXITCODE -ne 0){throw 'Migration rehearsal failed; existing application files were not replaced'}
 $changed=$true
 Get-ChildItem -LiteralPath $app -Force|ForEach-Object{Copy-Item -LiteralPath $_.FullName -Destination $target -Recurse -Force}
 Start-ScheduledTask -TaskName 'ActivityTAB Server'
 $healthy=$false
 for($i=0;$i -lt 30;$i++){
  try{$health=Invoke-RestMethod 'http://127.0.0.1:3187/ActivityTAB/health';if($health.ok -and $health.release -eq $manifest.version){$healthy=$true;break}}catch{}
  Start-Sleep -Seconds 1
 }
 if(-not $healthy){throw 'Updated process did not pass health and release checks'}
 foreach($name in @('app.js','app.css','manifest.webmanifest','sw.js')){
  $response=Invoke-WebRequest -UseBasicParsing ('http://127.0.0.1:3187/ActivityTAB/'+$name)
  if($response.StatusCode -ne 200){throw ('Static asset check failed: '+$name)}
 }
 if($poolWasRunning){Start-WebAppPool -Name 'ActivityTAB'}
 $stopped=$false
 $result=[ordered]@{ok=$true;release=$manifest.version;verifiedAt=(Get-Date).ToUniversalTime().ToString('o');backup=$backup;database='SQLite';sqlServerMigrationComplete=$false}
 $result|ConvertTo-Json|Set-Content -Encoding UTF8 (Join-Path $private 'last-deployment.json')
 try{$result|ConvertTo-Json|Set-Content -Encoding UTF8 (Join-Path $share 'ActivityTAB-deployment-result.json')}catch{Write-Host 'Update succeeded. The redirected Mac folder is read-only; the report is saved privately on the server.'}
 Write-Host ('UPDATE VERIFIED: '+$manifest.version) -ForegroundColor Green
}catch{
 $failure=$_.Exception.Message
 if($stopped){
  try{
   Stop-App
   if($changed){
    $failed=Join-Path $backup 'failed-database';New-Item -ItemType Directory -Path $failed|Out-Null
    Get-ChildItem -LiteralPath $data -File|Where-Object{$_.Name -like 'activitytab.sqlite*'}|ForEach-Object{Move-Item -LiteralPath $_.FullName -Destination $failed}
    Get-ChildItem -LiteralPath (Join-Path $backup 'data') -File|Where-Object{$_.Name -like 'activitytab.sqlite*'}|ForEach-Object{Copy-Item -LiteralPath $_.FullName -Destination $data}
    Get-ChildItem -LiteralPath (Join-Path $backup 'app') -Force|ForEach-Object{Copy-Item -LiteralPath $_.FullName -Destination $target -Recurse -Force}
   }
   Start-ScheduledTask -TaskName 'ActivityTAB Server'
   if($poolWasRunning){Start-WebAppPool -Name 'ActivityTAB'}
   Write-Host 'Previous application restarted. Retained backup and failed database for investigation.'
  }catch{Write-Host ('Recovery needs attention: '+$_.Exception.Message) -ForegroundColor Red}
 }
 Write-Host ('UPDATE STOPPED: '+$failure) -ForegroundColor Red
}
Read-Host 'Press Enter to close'
