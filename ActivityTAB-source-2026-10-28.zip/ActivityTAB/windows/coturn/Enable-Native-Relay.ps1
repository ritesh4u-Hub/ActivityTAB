# Enables only the already-tested native Coturn package. Never reboots Windows.
$ErrorActionPreference='Stop'
$root='C:\ProgramData\ActivityTAB\coturn'
$private='C:\ProgramData\ActivityTAB'
$app='C:\inetpub\wwwroot\CFOProject\ActivityTAB'
$runner=Join-Path $private 'Run-ActivityTAB.cmd'
$taskName='ActivityTAB TURN Relay'
$firewallNames=@('ActivityTAB-TURN-UDP','ActivityTAB-TURN-TCP','ActivityTAB-TURN-Media')
$taskCreated=$false;$runnerChanged=$false;$backup=$null;$rulesCreated=@()
try {
 if(Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue){throw 'A relay task already exists. Inspect it before changing configuration.'}
 $address=Get-NetIPAddress -AddressFamily IPv4 | Where-Object {$_.IPAddress -eq '80.65.208.80'}
 if(-not $address){throw 'Expected public IPv4 is not directly assigned. NAT mapping must be checked before enabling the relay.'}
 if((Get-NetUDPEndpoint -LocalPort 3478 -ErrorAction SilentlyContinue) -or (Get-NetTCPConnection -LocalPort 3478 -State Listen -ErrorAction SilentlyContinue)){throw 'Relay port 3478 is already occupied'}
 if(-not(Test-Path $runner)){throw 'Existing application runner not found'}
 $oldRunner=[IO.File]::ReadAllText($runner)
 if($oldRunner -match 'ACTIVITYTAB_TURN_|Load-ActivityTAB-RTC'){throw 'Runner already contains relay configuration; inspect before modifying'}
 $backup=Join-Path $private ('backups\turn-enable-'+(Get-Date -Format yyyyMMdd-HHmmss))
 New-Item -ItemType Directory -Path $backup,$root -Force | Out-Null
 Copy-Item $runner (Join-Path $backup 'Run-ActivityTAB.cmd')
 & icacls.exe $root /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-19:(OI)(CI)RX' | Out-Null
 if($LASTEXITCODE -ne 0){throw 'Private relay permissions failed'}
 $zip=Join-Path $root 'package.zip'
 Copy-Item '\\tsclient\server-transfer\Coturn-Official-Windows.zip' $zip -Force
 if((Get-FileHash $zip -Algorithm SHA256).Hash -ne '5d9100241ae329fae4212e2d11abefdd560f59d35426fa8ac2d8838378a1972d'){throw 'Coturn package checksum failed'}
 Expand-Archive $zip (Join-Path $root 'runtime') -Force
 $bin=Join-Path $root 'runtime\bin';$exe=Join-Path $bin 'turnserver.exe'
 $logs=Join-Path $root 'logs';New-Item -ItemType Directory $logs -Force | Out-Null
 & icacls.exe $logs /grant:r '*S-1-5-19:(OI)(CI)M' | Out-Null
 if($LASTEXITCODE -ne 0){throw 'Relay log permissions failed'}
 $bytes=New-Object byte[] 32;$rng=[Security.Cryptography.RandomNumberGenerator]::Create();$rng.GetBytes($bytes);$rng.Dispose();$secret=([BitConverter]::ToString($bytes)).Replace('-','').ToLower()
 @"
listening-ip=80.65.208.80
relay-ip=80.65.208.80
listening-port=3478
min-port=50000
max-port=59999
realm=mis-sweetdreams.in
server-name=mis-sweetdreams.in
use-auth-secret
static-auth-secret=$secret
fingerprint
relay-threads=2
user-quota=24
total-quota=2400
max-bps=2000000
bps-capacity=50000000
no-cli
no-tls
no-dtls
no-tcp-relay
no-multicast-peers
no-rfc5780
no-stun-backward-compatibility
no-stdout-log
log-file=logs/turn.log
pidfile=logs/turn.pid
denied-peer-ip=0.0.0.0-0.255.255.255
denied-peer-ip=10.0.0.0-10.255.255.255
denied-peer-ip=100.64.0.0-100.127.255.255
denied-peer-ip=127.0.0.0-127.255.255.255
denied-peer-ip=169.254.0.0-169.254.255.255
denied-peer-ip=172.16.0.0-172.31.255.255
denied-peer-ip=192.0.0.0-192.0.0.255
denied-peer-ip=192.168.0.0-192.168.255.255
denied-peer-ip=198.18.0.0-198.19.255.255
denied-peer-ip=224.0.0.0-255.255.255.255
"@ | Set-Content (Join-Path $root 'turnserver.conf') -Encoding ASCII
 # App-local DLLs from the official archive; no global runtime installation.
 @"
@echo off
cd /d "$root"
:again
"$exe" -c turnserver.conf
timeout /t 5 /nobreak >nul
goto again
"@ | Set-Content (Join-Path $root 'Run-Relay.cmd') -Encoding ASCII
 $action=New-ScheduledTaskAction -Execute 'C:\Windows\System32\cmd.exe' -Argument ('/c ""'+(Join-Path $root 'Run-Relay.cmd')+'""') -WorkingDirectory $root
 $principal=New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\LOCAL SERVICE' -LogonType ServiceAccount -RunLevel Limited
 $settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -StartWhenAvailable -MultipleInstances IgnoreNew -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
 Register-ScheduledTask -TaskName $taskName -Action $action -Principal $principal -Settings $settings -Trigger (New-ScheduledTaskTrigger -AtStartup) -Description 'Authenticated ActivityTAB audio/video relay with temporary participant credentials.' | Out-Null
 $taskCreated=$true
 Start-ScheduledTask -TaskName $taskName
 Start-Sleep -Seconds 3
 if(-not(Get-NetUDPEndpoint -LocalAddress '80.65.208.80' -LocalPort 3478 -ErrorAction SilentlyContinue)){throw 'Relay UDP listener failed'}
 if(-not(Get-NetTCPConnection -LocalAddress '80.65.208.80' -LocalPort 3478 -State Listen -ErrorAction SilentlyContinue)){throw 'Relay TCP listener failed'}
 New-NetFirewallRule -Name $firewallNames[0] -DisplayName 'ActivityTAB TURN UDP' -Direction Inbound -Action Allow -Protocol UDP -LocalPort 3478 -Program $exe -Profile Any | Out-Null
 $rulesCreated += $firewallNames[$($rulesCreated.Count)]
 New-NetFirewallRule -Name $firewallNames[1] -DisplayName 'ActivityTAB TURN TCP' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 3478 -Program $exe -Profile Any | Out-Null
 $rulesCreated += $firewallNames[$($rulesCreated.Count)]
 New-NetFirewallRule -Name $firewallNames[2] -DisplayName 'ActivityTAB TURN media' -Direction Inbound -Action Allow -Protocol UDP -LocalPort 50000-59999 -Program $exe -Profile Any | Out-Null
 $rulesCreated += $firewallNames[$($rulesCreated.Count)]
 @"
@echo off
set ACTIVITYTAB_TURN_URLS=turn:80.65.208.80:3478?transport=udp,turn:80.65.208.80:3478?transport=tcp
set ACTIVITYTAB_TURN_SECRET=$secret
"@ | Set-Content (Join-Path $root 'Load-ActivityTAB-RTC.cmd') -Encoding ASCII
 $newRunner=$oldRunner -replace '(?im)^@echo off',('@echo off'+[Environment]::NewLine+'call "'+(Join-Path $root 'Load-ActivityTAB-RTC.cmd')+'"')
 if($newRunner -eq $oldRunner){throw 'Runner format was not recognized'}
 [IO.File]::WriteAllText($runner,$newRunner,[Text.Encoding]::ASCII);$runnerChanged=$true
 # Restart only ActivityTAB's worker to read the relay environment. No IIS/site/OS restart.
 Stop-ScheduledTask -TaskName 'ActivityTAB Server';Start-Sleep -Seconds 2
 Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'node.exe' -and $_.CommandLine -like ('*'+$app+'\server.mjs*')} | ForEach-Object {Stop-Process -Id $_.ProcessId -ErrorAction SilentlyContinue}
 Start-ScheduledTask -TaskName 'ActivityTAB Server'
 $health=$null;for($i=0;$i -lt 20;$i++){try{$health=Invoke-RestMethod 'http://127.0.0.1:3187/ActivityTAB/health';if($health.ok){break}}catch{};Start-Sleep -Seconds 1}
 if(-not $health.ok){throw 'Application health check failed'}
 Write-Host 'AUTHENTICATED RELAY ENABLED: UDP/TCP 3478, UDP media 50000-59999. Windows was not restarted.' -ForegroundColor Green
 Write-Host 'Next: verify public relay traffic and real computer-to-phone audio/video.'
} catch {
 Write-Host ('ENABLE STOPPED: '+$_.Exception.Message) -ForegroundColor Red
 if($runnerChanged){Copy-Item (Join-Path $backup 'Run-ActivityTAB.cmd') $runner -Force;Stop-ScheduledTask -TaskName 'ActivityTAB Server' -ErrorAction SilentlyContinue;Start-Sleep -Seconds 1;Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'node.exe' -and $_.CommandLine -like ('*'+$app+'\server.mjs*')} | ForEach-Object {Stop-Process -Id $_.ProcessId -ErrorAction SilentlyContinue};Start-ScheduledTask -TaskName 'ActivityTAB Server'}
 if($taskCreated){Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue;Get-CimInstance Win32_Process | Where-Object {$_.ExecutablePath -eq (Join-Path $root 'runtime\bin\turnserver.exe')} | ForEach-Object {Stop-Process -Id $_.ProcessId -ErrorAction SilentlyContinue};Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue}
 foreach($name in $rulesCreated){Get-NetFirewallRule -Name $name -ErrorAction SilentlyContinue | Remove-NetFirewallRule}
}
Read-Host 'Press Enter to close'
