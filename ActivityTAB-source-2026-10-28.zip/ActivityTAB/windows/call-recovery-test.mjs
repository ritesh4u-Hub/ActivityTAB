import assert from 'node:assert/strict';
import {readFileSync,realpathSync} from 'node:fs';
import {createRequire} from 'node:module';
import vm from 'node:vm';
const {transform}=createRequire(realpathSync('node_modules/wrangler/package.json'))('esbuild');
const page=readFileSync('app/page.tsx','utf8');
const refresh=page.slice(page.indexOf('async function refresh()'),page.indexOf('useEffect(()=>{const params='));
assert.ok(refresh.startsWith('async function refresh()'));
const {code:refreshCode}=await transform(refresh,{loader:'ts'});
for(let cycle=1;cycle<=3;cycle++){
 let failure=null,authError=null,connectionError='',state={me:{id:'self'}};
 const context={api:async()=>{if(failure)throw failure;return state},settingsDirty:{current:false},setState(v){state=v},setSettingsState(){},setAuthError(v){authError=v},setConnectionError(v){connectionError=v},setLoading(){}};
 vm.runInNewContext(refreshCode,context);
 for(const error of [Object.assign(Error('signal timed out'),{name:'TimeoutError'}),Error('Failed to fetch'),Object.assign(Error('Unavailable'),{status:503})]){
  failure=error;await context.refresh();assert.equal(authError,null,'Temporary request failure must never trigger the workspace access gate');assert.ok(connectionError);assert.equal(state.me.id,'self');
 }
 failure=null;await context.refresh();assert.equal(connectionError,'');
 failure=Object.assign(Error('Sign in required'),{status:401});await context.refresh();assert.equal(authError.status,401,'Real access loss still enforces sign-in');
}
let source=readFileSync('app/meeting-room.tsx','utf8');const end=source.indexOf(' return <div className="meeting-overlay');assert.ok(end>0);
source=source.slice(0,end)+' return {join,poll,heartbeat,send,flushSignals,live};\n}\n';
const {code}=await transform(source,{loader:'tsx',format:'cjs',jsx:'automatic'});
function fixture(){
 const tracks=['audio','video'].map(kind=>({kind,stopped:false,stop(){this.stopped=true}}));
 const stream={getTracks:()=>tracks,getVideoTracks:()=>tracks.filter(t=>t.kind==='video'),getAudioTracks:()=>tracks.filter(t=>t.kind==='audio')};
 const meeting={id:'meeting',host:'self',auto_record:0,recordings:[],members:['self']};
 let mode='',closed=0,delivered=0;const timers=new Map();let id=0;
 const context={module:{exports:{}},exports:{},require(name){if(name==='react')return {useState:v=>[v,()=>{}],useRef:v=>({current:v}),useEffect(){}};return {}},crypto:{randomUUID:()=> 'same-session'},navigator:{mediaDevices:{getUserMedia:async()=>stream}},setTimeout(fn,ms){const key=++id;timers.set(key,{fn,ms});return key},clearTimeout(key){timers.delete(key)},Date,console};context.exports=context.module.exports;
 vm.runInNewContext(code,context);
 const api=async(path,method)=>{
  if(path.endsWith('/rtc'))return {iceServers:[]};
  if(path.endsWith('/live')){if(mode==='live-timeout')throw Error('signal timed out');if(mode==='forbidden')throw Object.assign(Error('No longer invited'),{status:403});return {...meeting,presence:mode==='missing'?[]:[{member:'self',session:'same-session'}]}}
  if(path.includes('/signals?')){if(mode==='signals-timeout')throw Error('signal timed out');if(mode==='expired')throw Object.assign(Error('Call session expired'),{status:409});return {signals:[]}}
  if(path.endsWith('/signals')&&method==='POST'){if(mode==='send-timeout')throw Error('signal timed out');delivered++;return {ok:true}}
  return {ok:true};
 };
 const room=context.module.exports.default({meeting,me:{id:'self',name:'Self'},members:[],api,apiBase:'/api/',onClose(){closed++},onMessage(){}});
 return {room,tracks,timers,setMode(v){mode=v},closed:()=>closed,delivered:()=>delivered};
}
const f=fixture();await f.room.join();
for(let cycle=1;cycle<=3;cycle++){
 const screen={stopped:false,stop(){this.stopped=true}};f.room.live.current.display={getTracks:()=>[screen]};
 for(const mode of ['live-timeout','signals-timeout','expired','missing']){
  f.setMode(mode);await f.room.poll();assert.equal(f.room.live.current.joined,true,mode+' must retain the call');assert.equal(f.closed(),0);assert.ok(f.tracks.every(t=>!t.stopped));assert.equal(screen.stopped,false,'Transient failure preserves screen capture');
 }
 f.setMode('send-timeout');await f.room.send('other','peer-session',{type:'ice',candidate:{candidate:'fixture'}});assert.equal(f.room.live.current.outbox.length,1,'Undelivered signal is retained');
 f.setMode('');await f.room.heartbeat();await f.room.poll();assert.equal(f.room.live.current.outbox.length,0);assert.equal(f.delivered(),cycle);assert.ok([...f.timers.values()].some(t=>t.ms===4000),'Independent heartbeat remains scheduled');
}
f.setMode('forbidden');await f.room.poll();assert.equal(f.closed(),1,'Real access revocation ends call');assert.ok(f.tracks.every(t=>t.stopped));assert.equal(f.room.live.current.closed,true);
console.log('PASS: three actual workspace-refresh recovery cycles and three actual MeetingRoom timeout/recovery cycles; missing heartbeat and 409 expiration do not eject users; outbound signals retry; access revocation still ends the call. Network/media APIs mocked; not a physical remote-device test.');
