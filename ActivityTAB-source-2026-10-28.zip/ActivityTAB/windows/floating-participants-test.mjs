import assert from 'node:assert/strict';import vm from 'node:vm';import {readFileSync,realpathSync} from 'node:fs';import{createRequire}from'node:module';
const{transform}=createRequire(realpathSync('node_modules/wrangler/package.json'))('esbuild');
const{code}=await transform(readFileSync('app/floating-participants.tsx','utf8'),{loader:'tsx',format:'cjs',jsx:'automatic'});
function setup(){const values=[],refs=[],cleanups=[];let cursor=0,refCursor=0,effectDone=false,fail=false,pending=null;const windows=[],errors=[];
 const make=()=>{const handlers={};const panel={closed:false,document:{head:{appendChild(){}},body:{appendChild(){}},createElement(tag){return {tag}}},addEventListener(type,fn){handlers[type]=fn},close(){this.closed=true;handlers.pagehide?.()},focus(){}};windows.push(panel);return panel};
 const context={module:{exports:{}},exports:{},window:{documentPictureInPicture:{requestWindow(){if(fail)return Promise.reject(Error('Blocked'));return pending||Promise.resolve(make())}}},require(n){if(n==='react')return {useState(initial){const i=cursor++;if(!(i in values))values[i]=initial;return [values[i],v=>values[i]=v]},useRef(initial){const i=refCursor++;return refs[i]??=( {current:initial})},useEffect(fn){if(!effectDone)cleanups.push(fn())}};if(n==='react-dom')return {createPortal:(children,target)=>({portal:true,children,target})};if(n==='react/jsx-runtime')return {jsx:(type,props)=>({type,props}),jsxs:(type,props)=>({type,props}),Fragment:'Fragment'};throw Error(n)}};context.exports=context.module.exports;vm.runInNewContext(code,context);
 const children={sameCallStreams:true};const render=()=>{cursor=0;refCursor=0;const tree=context.module.exports.default({children,onError:e=>errors.push(e)});effectDone=true;return tree};
 const button=tree=>tree.props.children[0].props.children[0];return {render,button,windows,errors,children,fail(v){fail=v},hold(p){pending=p},unmount(){cleanups.forEach(fn=>fn?.())}};
}
const f=setup();
for(let cycle=1;cycle<=3;cycle++){
 let view=f.render();assert.equal(view.props.children[1],f.children);await f.button(view).props.onClick();view=f.render();assert.equal(view.props.children[1].portal,true);assert.equal(view.props.children[1].children,f.children,'Existing call view is reused');
 if(cycle===2)f.windows.at(-1).close();else f.button(view).props.onClick();
 view=f.render();assert.equal(view.props.children[1],f.children,'Videos return to call');assert.equal(f.windows.at(-1).closed,true);
}
f.fail(true);await f.button(f.render()).props.onClick();assert.equal(f.errors.length,1);assert.equal(f.render().props.children[1],f.children,'Popup failure leaves call view intact');f.unmount();
const late=setup();let resolve;late.hold(new Promise(r=>resolve=r));const opening=late.button(late.render()).props.onClick();late.unmount();let closed=false;resolve({close(){closed=true}});await opening;assert.equal(closed,true,'Window delivered after Leave is closed');
console.log('PASS: three floating-panel open/close cycles, browser-close recovery, same call-view reuse, blocked-popup fallback, unmount cleanup and late-window cleanup. Window APIs mocked; real browser PiP requires separate verification.');
