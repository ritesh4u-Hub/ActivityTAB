import assert from 'node:assert/strict';
import {readFileSync,realpathSync} from 'node:fs';
import {createRequire} from 'node:module';
import vm from 'node:vm';
const {transform}=createRequire(realpathSync('node_modules/wrangler/package.json'))('esbuild');
// Exercise the actual room's join/recording lifecycle with browser device APIs mocked.
// Real phone/network/media delivery remains a separate acceptance test.
let source=readFileSync('app/meeting-room.tsx','utf8');
const end=source.indexOf(' return <div className="meeting-overlay');assert.ok(end>0);
source=source.slice(0,end)+' return {join,leave,live};\n}\n';
const {code}=await transform(source,{loader:'tsx',format:'cjs',jsx:'automatic'});
async function scenario(failRecording){
 const calls=[],tracks=[{kind:'audio',stop(){this.stopped=true}},{kind:'video',stop(){this.stopped=true}}],captureTrack={kind:'video',stop(){this.stopped=true}};
 const stream={getTracks:()=>tracks,getAudioTracks:()=>[tracks[0]],getVideoTracks:()=>[tracks[1]]},capture={getTracks:()=>[captureTrack],getVideoTracks:()=>[captureTrack]};
 let release,recordRequested=false;
 const hold=new Promise(r=>release=r);
 const module={exports:{}};
 class Recorder{static isTypeSupported(){return true}start(){calls.push('recorder-start')}state='recording'}
 class Audio{async resume(){}async close(){}createMediaStreamDestination(){return {stream:{getAudioTracks:()=>[{kind:'audio'}]}}}createMediaStreamSource(){return {connect(){}}}}
 const context={module,exports:module.exports,require(name){if(name==='react')return {useState:value=>[value,()=>{}],useRef:value=>({current:value}),useEffect:()=>{}};return {}},crypto:{randomUUID:()=> 'test-session'},navigator:{mediaDevices:{async getDisplayMedia(){return capture},async getUserMedia(){return stream}}},window:{MediaRecorder:Recorder},MediaRecorder:Recorder,MediaStream:class{constructor(tracks){this.tracks=tracks}},AudioContext:Audio,setTimeout:()=>0,clearTimeout(){},console};
 vm.runInNewContext(code,context);
 const meeting={id:'test',host:'self',auto_record:1,recordings:[],members:['self']};
 const api=async(path,method)=>{calls.push(path.split('/').at(-1));if(path.endsWith('/rtc'))return {iceServers:[]};if(path.endsWith('/live'))return {...meeting,presence:[{member:'self',session:'test-session'}]};if(path.includes('/signals?'))return {signals:[]};if(path.endsWith('/recordings')&&method==='POST'){recordRequested=true;await hold;if(failRecording)throw Error('Fixture recording upload unavailable');return {id:'recording'}};return {ok:true}};
 const room=module.exports.default({meeting,me:{id:'self',name:'Self'},members:[],api,onClose(){},onMessage(){},apiBase:'/api/'});
 const joining=room.join();for(let i=0;i<30;i++)await Promise.resolve();
 assert.ok(recordRequested,'Recording requested');assert.ok(calls.some(x=>x.startsWith('signals?')),'Call signaling runs while recording setup is still pending');assert.equal(room.live.current.joined,true,'Call is joined before recording setup completes');
 release();await joining;
 assert.ok(tracks.every(t=>!t.stopped),'Recording setup must never stop the camera or microphone');
 if(failRecording){assert.equal(room.live.current.joined,true,'Recording failure leaves the call connected');assert.equal(captureTrack.stopped,true,'Failed recording capture is released')}
 else assert.ok(calls.includes('recorder-start'),'Recorder starts after server registration');
}
await scenario(false);await scenario(true);
console.log('PASS: Recording success and failure; pending recording cannot block signaling; camera/microphone remain active. Mocked device APIs, no real meeting media.');
