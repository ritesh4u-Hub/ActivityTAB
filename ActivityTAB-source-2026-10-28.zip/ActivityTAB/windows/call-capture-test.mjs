import assert from 'node:assert/strict';
import {readFileSync,realpathSync} from 'node:fs';
import {createRequire} from 'node:module';
import vm from 'node:vm';
const {transform}=createRequire(realpathSync('node_modules/wrangler/package.json'))('esbuild');
const {code}=await transform(readFileSync('lib/call-capture.ts','utf8'),{loader:'ts',format:'cjs'});
let mode='frame',video,picker=()=>Promise.reject(Error('Unset test picker'));
class Video extends EventTarget{
 style={};videoWidth=0;videoHeight=0;readyState=0;removed=false;paused=false;srcObject=null;
 setAttribute(){} remove(){this.removed=true} pause(){this.paused=true}
 play(){if(mode==='rejected')return Promise.reject(Error('blocked'));if(mode==='frame')queueMicrotask(()=>{this.videoWidth=1280;this.videoHeight=720;this.readyState=2;this.dispatchEvent(new Event('loadeddata'))});return Promise.resolve()}
}
const module={exports:{}};vm.runInNewContext(code,{module,exports:module.exports,setTimeout,clearTimeout,setInterval,clearInterval,navigator:{mediaDevices:{getDisplayMedia:options=>picker(options)}},document:{createElement:()=>video=new Video(),body:{appendChild(){}}}});
const {requestScreenCapture,waitForCaptureFrame}=module.exports;
function source(){const track=new EventTarget();track.readyState='live';track.stopped=false;track.stop=()=>track.stopped=true;return {getVideoTracks:()=>[track],getTracks:()=>[track],track}}
function cleaned(stream){assert.equal(video.removed,true);assert.equal(video.paused,true);assert.equal(video.srcObject,null);assert.equal(stream.track.stopped,false,'caller retains capture ownership')}
let stream=source();await waitForCaptureFrame(stream,100);cleaned(stream);
mode='empty';stream=source();await assert.rejects(waitForCaptureFrame(stream,10),/did not provide a screen picture/);cleaned(stream);
stream=source();const pending=waitForCaptureFrame(stream,100);stream.track.readyState='ended';stream.track.dispatchEvent(new Event('ended'));await assert.rejects(pending,/ended before/);cleaned(stream);
mode='rejected';stream=source();await assert.rejects(waitForCaptureFrame(stream,100),/could not play/);cleaned(stream);
await assert.rejects(waitForCaptureFrame({getVideoTracks:()=>[]}),/no longer available/);
mode='empty';stream=source();const cancel=new AbortController();const cancelled=waitForCaptureFrame(stream,100,cancel.signal);cancel.abort();await assert.rejects(cancelled,e=>e.name==='AbortError');cleaned(stream);
const alreadyCancelled=new AbortController();alreadyCancelled.abort();await assert.rejects(waitForCaptureFrame(source(),100,alreadyCancelled.signal),e=>e.name==='AbortError');
let calls=0;picker=()=>{calls++;return Promise.resolve(stream)};stream=source();const incoming=requestScreenCapture({video:true},new AbortController().signal,100);assert.equal(calls,1,'Picker must open synchronously in the click call stack');const owned=await incoming;assert.equal(owned,stream);assert.equal(stream.track.stopped,false);
let late;picker=()=>new Promise(resolve=>late=resolve);let control=new AbortController();const request=requestScreenCapture({video:true},control.signal,100);control.abort();await assert.rejects(request,e=>e.name==='AbortError');stream=source();late(stream);await Promise.resolve();assert.equal(stream.track.stopped,true,'Capture arriving after cancellation must be stopped');
picker=()=>new Promise(resolve=>late=resolve);await assert.rejects(requestScreenCapture({video:true},new AbortController().signal,10),/selection did not finish/);stream=source();late(stream);await Promise.resolve();assert.equal(stream.track.stopped,true,'Capture arriving after timeout must be stopped');
control=new AbortController();control.abort();calls=0;picker=()=>{calls++;return Promise.resolve(source())};await assert.rejects(requestScreenCapture({video:true},control.signal),e=>e.name==='AbortError');assert.equal(calls,0,'Already cancelled requests must not open a picker');
picker=()=>{throw Error('Device API failed')};await assert.rejects(requestScreenCapture({video:true},new AbortController().signal),/Device API failed/);
console.log('PASS: actual frame readiness, live-but-empty timeout, ended source, playback rejection, probe cleanup, track ownership and immediate cancellation, picker timeout, late-stream cleanup and synchronous API failure.');
