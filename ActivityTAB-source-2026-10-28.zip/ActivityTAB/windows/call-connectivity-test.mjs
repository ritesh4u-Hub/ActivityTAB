import assert from 'node:assert/strict';
import {readFileSync,realpathSync} from 'node:fs';
import {createRequire} from 'node:module';
import vm from 'node:vm';
const {transform}=createRequire(realpathSync('node_modules/wrangler/package.json'))('esbuild');
const {code}=await transform(readFileSync('lib/call-connectivity.ts','utf8'),{loader:'ts',format:'cjs'});
for(const mode of ['success','timeout','negotiation-failure']){
 const instances=[],module={exports:{}};
 class Peer{
  constructor(config){assert.equal(config.iceTransportPolicy,'relay');instances.push(this)}
  createDataChannel(){return this.channel={send:data=>instances[1].incoming?.onmessage({data})}}
  async createOffer(){if(mode==='negotiation-failure')throw Error('fixture');return {type:'offer'}}
  async createAnswer(){return {type:'answer'}}
  async setLocalDescription(value){this.localDescription=value}
  async setRemoteDescription(value){this.remoteDescription=value;if(value.type==='offer'){this.incoming={send:data=>instances[0].channel.onmessage({data})};this.ondatachannel({channel:this.incoming})}else if(mode==='success')queueMicrotask(()=>this.channel.onopen())}
  async addIceCandidate(){}close(){this.closed=true}
 }
 vm.runInNewContext(code,{module,exports:module.exports,RTCPeerConnection:Peer,setTimeout,clearTimeout,queueMicrotask});
 const run=module.exports.checkCallRelay([{urls:'turn:fixture.invalid'}],25);
 if(mode==='success')await run;else await assert.rejects(run,mode==='timeout'?/timed out/:/negotiation failed/);
 assert.equal(instances.length,2);assert.ok(instances.every(p=>p.closed),'Diagnostic peers must always close');
}
console.log('PASS: relay-only round trip, timeout, negotiation failure, and cleanup. Simulated peer APIs; real relay traffic is tested separately in the live browser.');
