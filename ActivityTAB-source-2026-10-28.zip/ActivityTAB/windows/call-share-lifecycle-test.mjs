import assert from 'node:assert/strict';
import {readFileSync,realpathSync} from 'node:fs';
import {createRequire} from 'node:module';
import vm from 'node:vm';
const {transform}=createRequire(realpathSync('node_modules/wrangler/package.json'))('esbuild');
let source=readFileSync('app/meeting-room.tsx','utf8');const end=source.indexOf(' return <div className="meeting-overlay');assert.ok(end>0);
source=source.slice(0,end)+' return {join,shareScreen,stopShare,leave,live};\n}\n';
const {code}=await transform(source,{loader:'tsx',format:'cjs',jsx:'automatic'});
const {code:captureCode}=await transform(readFileSync('lib/call-capture.ts','utf8'),{loader:'ts',format:'cjs'});
function deferred(){let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve}}
async function settle(){for(let n=0;n<30;n++)await Promise.resolve()}
function track(kind){return {kind,readyState:'live',stops:0,stop(){this.readyState='ended';this.stops++}}}
function stream(t){return {getVideoTracks:()=>[t],getTracks:()=>[t],getAudioTracks:()=>[]}}
function fixture(mode){
 const cameraTrack=track('video'),camera=stream(cameraTrack),acquisition=deferred(),frames=deferred(),screenTracks=[],attached=[];let frameProbeStarted=false;
 const module={exports:{}},captureModule={exports:{}};const meeting={id:'test',host:'self',auto_record:0,recordings:[],members:['self']};
 const context={module,exports:module.exports,AbortController,crypto:{randomUUID:()=> 'test-session'},setTimeout:()=>0,clearTimeout(){},require(name){
  if(name==='react')return {useState:v=>[v,()=>{}],useRef:v=>({current:v}),useEffect:()=>{}};
  if(name.endsWith('call-presentation'))return {async setPresentationTrack(peers,t){attached.push(t)},presentationMessage:sharing=>JSON.stringify({sharing})};
  if(name.endsWith('call-capture'))return {...captureModule.exports,waitForCaptureFrame(s,t,signal){frameProbeStarted=true;if(mode==='ready')return Promise.resolve();return new Promise((resolve,reject)=>{signal.addEventListener('abort',()=>reject(Object.assign(Error('Stopped'),{name:'AbortError'})),{once:true});frames.promise.then(resolve)})}};
  return {};
 },navigator:{mediaDevices:{getUserMedia:async()=>camera,getDisplayMedia:async()=>{const t=track('video');screenTracks.push(t);const s=stream(t);return mode==='picker'?acquisition.promise:s}}}};
 vm.runInNewContext(captureCode,{module:captureModule,exports:captureModule.exports,setTimeout,clearTimeout,navigator:context.navigator});
 vm.runInNewContext(code,context);
 const api=async path=>path.endsWith('/rtc')?{iceServers:[]}:path.endsWith('/live')?{...meeting,presence:[{member:'self',session:'test-session'}]}:path.includes('/signals?')?{signals:[]}:{ok:true};
 const room=module.exports.default({meeting,me:{id:'self',name:'Self'},members:[],api,onClose(){},onMessage(){},apiBase:'/api/'});
 return {room,cameraTrack,screenTracks,attached,acquisition,frames,probe:()=>frameProbeStarted};
}
{
 const f=fixture('picker');await f.room.join();const sharing=f.room.shareScreen();await settle();await f.room.leave();f.acquisition.resolve(stream(f.screenTracks[0]));await sharing;
 assert.equal(f.screenTracks[0].readyState,'ended','Late stream after Leave is immediately stopped');assert.equal(f.probe(),false,'A closed meeting never starts a capture probe');assert.equal(f.attached.filter(Boolean).length,0);assert.equal(f.room.live.current.display,null);assert.equal(f.room.live.current.pendingShare,null);assert.equal(f.room.live.current.shareBusy,false);
}
{
 const f=fixture('probing');await f.room.join();const sharing=f.room.shareScreen();await settle();assert.equal(f.probe(),true);await f.room.stopShare();assert.equal(f.screenTracks[0].readyState,'ended','Stop immediately releases capture while awaiting its first frame');await sharing;assert.equal(f.attached.filter(Boolean).length,0);assert.equal(f.cameraTrack.readyState,'live');await f.room.leave();
}
{
 const f=fixture('ready');await f.room.join();for(let n=0;n<3;n++){await f.room.shareScreen();assert.equal(f.room.live.current.display.getVideoTracks()[0],f.screenTracks[n]);await f.room.stopShare();assert.equal(f.screenTracks[n].readyState,'ended');assert.equal(f.room.live.current.display,null);assert.equal(f.room.live.current.pendingShare,null);assert.equal(f.cameraTrack.readyState,'live')};assert.equal(f.attached.filter(Boolean).length,3);await f.room.leave();
}
console.log('PASS: actual MeetingRoom lifecycle with mocked device APIs: late capture after Leave, cancellation during first-frame wait, three start/stop cycles, camera isolation and source cleanup. Not a physical-device media test.');
