'use client';
import {useEffect,useRef,useState} from 'react';
import {createPortal} from 'react-dom';

type PictureInPictureBrowser=Window&{documentPictureInPicture?:{requestWindow(options:{width:number,height:number}):Promise<Window>}};

/** Move the existing participant view into browser-managed Picture-in-Picture. */
export default function FloatingParticipants({children,onError}:{children:React.ReactNode,onError:(message:string)=>void}){
 const [target,setTarget]=useState<HTMLElement|null>(null),[opening,setOpening]=useState(false);
 const pip=useRef<Window|null>(null),mounted=useRef(true);
 const supported=typeof window!=='undefined'&&!!(window as PictureInPictureBrowser).documentPictureInPicture?.requestWindow;
 useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;const current=pip.current;pip.current=null;current?.close()}},[]);
 async function open(){
  if(opening)return;
  if(pip.current&&!pip.current.closed){pip.current.focus();return}
  const api=(window as PictureInPictureBrowser).documentPictureInPicture;if(!api?.requestWindow){onError('Floating participant videos need a desktop browser with Document Picture-in-Picture support.');return}
  setOpening(true);
  try{
   // Request directly from the button gesture. Reuse streams; never acquire media here.
   const panel:Window=await api.requestWindow({width:420,height:420});
   if(!mounted.current){panel.close();return}
   if(panel.closed)throw Error('Floating window closed before opening');
   pip.current=panel;panel.document.title='ActivityTAB · Participants';
   const style=panel.document.createElement('style');
   style.textContent='*{box-sizing:border-box}body{margin:0;padding:10px;background:#10251d;color:#fff;font:13px system-ui}.call-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin:0}.call-feed{position:relative;background:#203a2d;border-radius:8px;overflow:hidden;aspect-ratio:4/3;min-width:0}.call-feed video{width:100%;height:100%;object-fit:contain}.call-feed>span{position:absolute;bottom:4px;left:4px;max-width:95%;padding:3px 5px;background:#0009;border-radius:4px;font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.call-placeholder,.call-waiting{display:grid;place-content:center;min-height:100px;text-align:center}.call-playback{position:absolute;inset:25% 5%;border:0;border-radius:6px;background:#fff;color:#173c30}.call-waiting small{display:none}';
   panel.document.head.appendChild(style);const root=panel.document.createElement('div');panel.document.body.appendChild(root);
   panel.addEventListener('pagehide',()=>{if(pip.current!==panel)return;pip.current=null;if(mounted.current)setTarget(null)},{once:true});
   setTarget(root);
  }catch(e:unknown){const failed=pip.current;pip.current=null;failed?.close();if(mounted.current){setTarget(null);onError(typeof e==='object'&&e!==null&&'name' in e&&e.name==='NotAllowedError'?'Your browser blocked the floating panel. Click Float participant videos to try again.':'Could not open the floating participant panel. Your call remains connected.')}}
  finally{if(mounted.current)setOpening(false)}
 }
 function close(){const current=pip.current;pip.current=null;setTarget(null);current?.close()}
 return <>{supported&&<div className="call-floating-actions"><button className="button" disabled={opening} onClick={target?close:open}>{opening?'Opening panel…':target?'Bring videos back':'Float participant videos'}</button>{target&&<span role="status">Participant videos are in the floating panel. Keep this meeting open.</span>}</div>}{target?createPortal(children,target):children}</>;
}
