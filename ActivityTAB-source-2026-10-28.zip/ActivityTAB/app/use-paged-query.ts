'use client';
import {useEffect,useRef,useState} from 'react';
export function usePagedQuery(api:any,path:string,enabled:boolean,revision:any,onError:(s:string)=>void){
 const [page,setPage]=useState<any>(null),[loading,setLoading]=useState(false),[history,setHistory]=useState<string[]>(['']);
 const generation=useRef(0),pathRef=useRef(path);pathRef.current=path;
 async function load(cursor:string,trail:string[]){const version=++generation.current;setLoading(true);try{const data=await api(pathRef.current+(cursor?'&cursor='+encodeURIComponent(cursor):''));if(version===generation.current){setPage(data);setHistory(trail)}}catch(e:any){if(version===generation.current)onError(e.message)}finally{if(version===generation.current)setLoading(false)}}
 useEffect(()=>{generation.current++;if(!enabled){setLoading(false);return}setPage(null);setHistory(['']);const timer=setTimeout(()=>load('',['']),path.includes('&q=')&&!path.endsWith('&q=')?250:0);return()=>{clearTimeout(timer);generation.current++}},[path,enabled,revision]);
 return {page,loading,previous:history.length>1&&!loading?()=>load(history[history.length-2],history.slice(0,-1)):null,next:page?.next&&!loading?()=>load(page.next,[...history,page.next]):null};
}
