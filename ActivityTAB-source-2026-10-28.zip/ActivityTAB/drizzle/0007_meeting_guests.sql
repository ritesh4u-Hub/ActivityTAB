CREATE TABLE meeting_guest_links(meeting TEXT PRIMARY KEY,token TEXT NOT NULL UNIQUE,created TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 1);
CREATE TABLE meeting_guests(id TEXT PRIMARY KEY,meeting TEXT NOT NULL,name TEXT NOT NULL,token TEXT NOT NULL UNIQUE,status TEXT NOT NULL DEFAULT 'waiting',expires INTEGER NOT NULL,created TEXT NOT NULL);
CREATE INDEX meeting_guests_waiting ON meeting_guests(meeting,status,expires);
