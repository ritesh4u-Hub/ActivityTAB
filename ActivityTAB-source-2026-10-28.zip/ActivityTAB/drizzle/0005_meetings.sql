ALTER TABLE members ADD COLUMN photo TEXT;
CREATE TABLE meetings(id TEXT PRIMARY KEY,title TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',kind TEXT NOT NULL,location TEXT NOT NULL DEFAULT '',owner TEXT NOT NULL,host TEXT NOT NULL,start TEXT NOT NULL,end TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'scheduled',reminder INTEGER NOT NULL DEFAULT 15,auto_record INTEGER NOT NULL DEFAULT 0,notes TEXT NOT NULL DEFAULT '',notes_version INTEGER NOT NULL DEFAULT 0,created TEXT NOT NULL,updated TEXT NOT NULL);
CREATE INDEX meetings_time ON meetings(status,start,end);
CREATE TABLE meeting_members(meeting TEXT NOT NULL,member TEXT NOT NULL,PRIMARY KEY(meeting,member));
CREATE INDEX meeting_members_member ON meeting_members(member,meeting);
CREATE TABLE meeting_presence(meeting TEXT NOT NULL,member TEXT NOT NULL,session TEXT NOT NULL,seen TEXT NOT NULL,PRIMARY KEY(meeting,member));
CREATE TABLE meeting_signals(seq INTEGER PRIMARY KEY AUTOINCREMENT,meeting TEXT NOT NULL,sender TEXT NOT NULL,recipient TEXT NOT NULL,session TEXT NOT NULL,sender_session TEXT NOT NULL,payload TEXT NOT NULL,created TEXT NOT NULL);
CREATE INDEX meeting_signals_recipient ON meeting_signals(meeting,recipient,seq);
CREATE INDEX meeting_signals_created ON meeting_signals(created);
CREATE TABLE meeting_recordings(id TEXT PRIMARY KEY,meeting TEXT NOT NULL,recorder TEXT NOT NULL,mime TEXT NOT NULL,status TEXT NOT NULL,created TEXT NOT NULL,updated TEXT NOT NULL);
CREATE INDEX meeting_recordings_meeting ON meeting_recordings(meeting,created);
CREATE TABLE meeting_recording_parts(recording TEXT NOT NULL,part INTEGER NOT NULL,file TEXT NOT NULL UNIQUE,size INTEGER NOT NULL,PRIMARY KEY(recording,part));
ALTER TABLE notifications ADD COLUMN meeting TEXT;
CREATE INDEX notifications_meeting ON notifications(recipient,meeting,read);

CREATE INDEX notification_meeting_id ON notifications(meeting,id);
CREATE INDEX meeting_signals_sender_time ON meeting_signals(meeting,sender,created);
