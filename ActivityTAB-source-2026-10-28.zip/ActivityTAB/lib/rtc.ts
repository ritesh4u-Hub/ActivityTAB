import {env} from 'cloudflare:workers';
export async function meetingRtc(meeting:any,member:string){
 const config=(env as any).RTC;if(!config?.urls?.length||!config.secret)return {iceServers:[],relayConfigured:false,expiresAt:null};
 // Time-limited TURN REST credentials; the long-lived shared secret stays on the server.
 const expires=Math.min(Math.floor(Date.now()/1000)+3600,Math.floor(Date.parse(meeting.end)/1000)+300);
 const bytes=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(member))),suffix=Array.from(bytes.slice(0,12),n=>n.toString(16).padStart(2,'0')).join(''),username=expires+':'+suffix;
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(config.secret),{name:'HMAC',hash:'SHA-1'},false,['sign']);
 const signature=new Uint8Array(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(username))),credential=btoa(String.fromCharCode(...signature));
 return {iceServers:[{urls:config.urls,username,credential}],relayConfigured:true,expiresAt:expires*1000};
}
