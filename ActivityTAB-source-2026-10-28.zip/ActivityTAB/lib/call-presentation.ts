type PresentationPeer={pc:RTCPeerConnection;screenTransceiver:RTCRtpTransceiver|null};
/** Reserve a distinct video connection so sharing never replaces the camera's negotiated codec. */
export function reservePresentation(pc:RTCPeerConnection){
 const transceiver=pc.addTransceiver('video',{direction:'sendrecv'});
 const codecs=RTCRtpSender.getCapabilities?.('video')?.codecs;
 if(codecs&&transceiver.setCodecPreferences){
  // VP8 handles screen-size changes consistently across desktop and mobile receivers.
  const ordered=[...codecs.filter(c=>c.mimeType.toLowerCase()==='video/vp8'),...codecs.filter(c=>c.mimeType.toLowerCase()!=='video/vp8')];
  try{transceiver.setCodecPreferences(ordered)}catch{/* Keep browser defaults when codec ordering is unsupported. */}
 }
 return transceiver;
}
export function receivedPresentation(pc:RTCPeerConnection){return pc.getTransceivers().filter(t=>t.mid!==null&&t.receiver.track.kind==='video')[1]||null}
export async function setPresentationTrack(peers:Iterable<PresentationPeer>,track:MediaStreamTrack|null){
 if(track)track.contentHint='detail';
 const results=await Promise.allSettled(Array.from(peers).filter(p=>p.pc.connectionState!=='closed').map(async peer=>{
  if(!peer.screenTransceiver){if(['new','connecting'].includes(peer.pc.connectionState))return;throw Error('A participant needs to reopen ActivityTAB and rejoin to receive screen sharing.')}
  await peer.screenTransceiver.sender.replaceTrack(track);
 }));
 const failure=results.find((r):r is PromiseRejectedResult=>r.status==='rejected');if(failure)throw failure.reason;
}
export function presentationMessage(sharing:boolean){return JSON.stringify({type:'presentation',sharing})}
export function readPresentationMessage(data:unknown):boolean|null{
 if(typeof data!=='string'||data.length>256)return null;
 try{const value=JSON.parse(data);return value?.type==='presentation'&&typeof value.sharing==='boolean'?value.sharing:null}catch{return null}
}
