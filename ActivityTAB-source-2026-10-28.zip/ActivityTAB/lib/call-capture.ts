/** Bound the browser picker wait and release a stream returned after cancellation. */
export function requestScreenCapture(options:DisplayMediaStreamOptions,signal:AbortSignal,timeoutMs=60000):Promise<MediaStream>{
 const cancelled=()=>Object.assign(Error('Screen sharing was stopped.'),{name:'AbortError'});
 if(signal.aborted)return Promise.reject(cancelled());
 return new Promise((resolve,reject)=>{
  let settled=false;
  const clear=()=>{clearTimeout(timer);signal.removeEventListener('abort',abort)};
  const fail=(error:unknown)=>{if(settled)return;settled=true;clear();reject(error)};
  const abort=()=>fail(cancelled());
  const timer=setTimeout(()=>fail(Error('Screen selection did not finish. Close any open system picker and try again.')),timeoutMs);
  signal.addEventListener('abort',abort,{once:true});
  // Invoke within the original click gesture; do not defer the browser permission request.
  try{void navigator.mediaDevices.getDisplayMedia(options).then(stream=>{
   if(settled||signal.aborted){stream.getTracks().forEach(track=>track.stop());return}
   settled=true;clear();resolve(stream);
  },fail)}catch(error){fail(error)}
 });
}

/** Verify browser capture before advertising a presentation to participants. */
export function waitForCaptureFrame(stream:MediaStream, timeoutMs=12000,signal?:AbortSignal):Promise<void>{
 const aborted=()=>Object.assign(Error('Screen sharing was stopped.'),{name:'AbortError'});
 if(signal?.aborted)return Promise.reject(aborted());
 const track=stream.getVideoTracks()[0];
 if(!track||track.readyState!=='live')return Promise.reject(Error('The selected screen is no longer available.'));
 return new Promise((resolve,reject)=>{
  const video=document.createElement('video');
  video.muted=true;video.autoplay=true;video.playsInline=true;
  // Keep the tiny muted probe in the viewport; some browsers suspend off-screen video.
  video.style.cssText='position:fixed;right:0;bottom:0;width:2px;height:2px;opacity:.01;pointer-events:none';
  video.setAttribute('aria-hidden','true');
  let settled=false,frame:number|undefined;
  const cleanup=()=>{clearTimeout(timer);clearInterval(poll);signal?.removeEventListener('abort',abort);track.removeEventListener('ended',ended);video.removeEventListener('loadeddata',check);if(frame!==undefined)video.cancelVideoFrameCallback?.(frame);video.pause();video.srcObject=null;video.remove()};
  const finish=(error?:Error)=>{if(settled)return;settled=true;cleanup();if(error)reject(error);else resolve()};
  const ended=()=>finish(Error('Screen capture ended before a picture was received.'));
  const abort=()=>finish(aborted());
  const check=()=>{if(track.readyState!=='live'){ended();return}if(video.videoWidth>0&&video.videoHeight>0&&video.readyState>=2)finish()};
  const timer=setTimeout(()=>finish(Error('Your browser did not provide a screen picture. Sharing has not started.')),timeoutMs);
  const poll=setInterval(check,150);
  signal?.addEventListener('abort',abort,{once:true});track.addEventListener('ended',ended,{once:true});video.addEventListener('loadeddata',check);
  document.body.appendChild(video);video.srcObject=stream;
  if(video.requestVideoFrameCallback)frame=video.requestVideoFrameCallback(()=>check());
  void video.play().catch(()=>finish(Error('Your browser could not play the captured screen. Sharing has not started.')));
 });
}
