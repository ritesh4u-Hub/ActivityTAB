type CallPeer={pc:RTCPeerConnection};
export function callVideoTrack(camera:MediaStream,display:MediaStream|null):MediaStreamTrack{
 const track=display?.getVideoTracks().find(t=>t.readyState==='live')||camera.getVideoTracks()[0];
 if(!track)throw Error('No video track is available');return track;
}
export async function replaceCallVideo(peers:Iterable<CallPeer>,track:MediaStreamTrack){
 const results=await Promise.allSettled(Array.from(peers).filter(({pc})=>pc.connectionState!=='closed').map(async({pc})=>{
  const sender=pc.getSenders().find(s=>s.track?.kind==='video');
  if(!sender)throw Error('A participant has no video connection. Leave and rejoin the meeting.');
  await sender.replaceTrack(track);
 }));
 const failure=results.find((r):r is PromiseRejectedResult=>r.status==='rejected');if(failure)throw failure.reason;
}
export async function sendScreenVideo(peers:Iterable<CallPeer>,track:MediaStreamTrack){
 const snapshot=Array.from(peers);try{await replaceCallVideo(snapshot,track)}catch(error){
  // Some negotiated codecs reject a desktop stream larger than the camera envelope.
  if((error as Error).name!=='InvalidModificationError')throw error;
  await track.applyConstraints({width:{max:640},height:{max:360},frameRate:{max:20}});
  await replaceCallVideo(snapshot,track);
 }
}
