// Select only work whose next notification is not already in the durable outbox.
// A per-tick batch bounds scheduler work; deduplication advances the next batch naturally.
export function reminderCandidates(stamp:string,config:any){const repeat=Math.max(1,Number(config.repeatHours)||24),before=Math.max(0,Number(config.beforeHours)||24),escalate=Math.max(1,Number(config.escalateHours)||48);
 const lateBucket=`CAST((unixepoch(?) - unixepoch(t.due)) / ${repeat*3600} AS INTEGER)`,reviewBucket=`CAST((unixepoch(?) - unixepoch(t.submitted)) / ${repeat*3600} AS INTEGER)`;
 return {sql:`SELECT t.* FROM tasks t WHERE
 (t.status='submitted' AND t.submitted<=? AND NOT EXISTS(SELECT 1 FROM notifications n WHERE n.id='review:'||t.id||':'||t.submitted||':'||${reviewBucket})) OR
 (t.status IN ('pending','progress','returned') AND (
  (t.due>? AND t.due<=? AND NOT EXISTS(SELECT 1 FROM notifications n WHERE n.id='before:'||t.id||':'||t.due)) OR
  (t.due<=? AND (
   NOT EXISTS(SELECT 1 FROM notifications n WHERE n.id='late:'||t.id||':'||t.due||':'||${lateBucket}) OR
   (t.due<=? AND NOT EXISTS(SELECT 1 FROM notifications n WHERE n.id='escalation:'||t.id||':'||t.due||':'||${lateBucket})) OR
   (t.escalation_manager IS NOT NULL AND julianday(?)-julianday(t.due)>=COALESCE(t.escalation_hours,?)/24.0 AND (t.escalated_at IS NULL OR t.escalated_at<=?) AND EXISTS(SELECT 1 FROM members m WHERE m.id=t.escalation_manager AND m.active=1 AND m.role IN ('admin','manager')))
  )))) ORDER BY t.due,t.id LIMIT 500`,args:[new Date(Date.parse(stamp)-repeat*3600000).toISOString(),stamp,stamp,new Date(Date.parse(stamp)+before*3600000).toISOString(),stamp,stamp,new Date(Date.parse(stamp)-escalate*3600000).toISOString(),stamp,stamp,escalate,new Date(Date.parse(stamp)-repeat*3600000).toISOString()]};
}
