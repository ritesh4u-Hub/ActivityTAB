import {env} from 'cloudflare:workers';
import {id,now,one,rows,run} from './service';
import {meetingsRoute} from './meetings';
const fail=(message:string,status=400):never=>{throw Object.assign(Error(message),{status})};
const json=(value:any,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store','Referrer-Policy':'no-referrer'}});
export const guestSecret=()=>Array.from(crypto.getRandomValues(new Uint8Array(32)),x=>x.toString(16).padStart(2,'0')).join('');
export async function guestHash(value:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))),x=>x.toString(16).padStart(2,'0')).join('')}
export async function meetingPeople(mid:string){return rows("SELECT p.member AS id,COALESCE(m.name,g.name,'Participant') AS name,CASE WHEN g.id IS NULL THEN 0 ELSE 1 END AS guest FROM meeting_presence p LEFT JOIN members m ON m.id=p.member LEFT JOIN meeting_guests g ON g.id=p.member WHERE p.meeting=? AND p.seen>? AND (m.active=1 OR (g.status='approved' AND g.expires>?))",mid,new Date(Date.now()-20000).toISOString(),Date.now())}
export async function manageMeetingGuests(req:Request,m:any,me:any){
 if(![m.host,m.owner].includes(me.id)||me.guestMeeting)fail('Host or organiser access required',403);
 if(m.kind!=='online'||m.status!=='scheduled'||Date.parse(m.end)<Date.now())fail('Guest access is available only for an active online meeting');
 if(req.method==='GET')return json({enabled:!!(await one('SELECT enabled FROM meeting_guest_links WHERE meeting=?',m.id))?.enabled,guests:await rows("SELECT id,name,status,created FROM meeting_guests WHERE meeting=? AND expires>? AND status IN ('waiting','approved') ORDER BY created LIMIT 40",m.id,Date.now())});
 if(req.method!=='POST')fail('Not found',404);
 const b:any=await req.json();
 if(b.action==='enable'){
  const raw=guestSecret();
  await env.DB!.batch([
   env.DB!.prepare("INSERT INTO meeting_guest_links(meeting,token,created,enabled) VALUES(?,?,?,1) ON CONFLICT(meeting) DO UPDATE SET token=excluded.token,created=excluded.created,enabled=1").bind(m.id,await guestHash(raw),now()),
   env.DB!.prepare("DELETE FROM meeting_presence WHERE meeting=? AND member IN (SELECT id FROM meeting_guests WHERE meeting=?)").bind(m.id,m.id),
   env.DB!.prepare("UPDATE meeting_guests SET status='removed' WHERE meeting=?").bind(m.id)
  ]);
  return json({invite:raw});
 }
 if(b.action==='disable'){
  await env.DB!.batch([
   env.DB!.prepare('UPDATE meeting_guest_links SET enabled=0 WHERE meeting=?').bind(m.id),
   env.DB!.prepare("DELETE FROM meeting_presence WHERE meeting=? AND member IN (SELECT id FROM meeting_guests WHERE meeting=?)").bind(m.id,m.id),
   env.DB!.prepare("UPDATE meeting_guests SET status='removed' WHERE meeting=?").bind(m.id)
  ]);return json({ok:true});
 }
 if(!['approve','reject','remove'].includes(b.action))fail('Unknown guest action');
 const g=await one('SELECT id,status FROM meeting_guests WHERE id=? AND meeting=? AND expires>?',String(b.guest||''),m.id,Date.now());if(!g)fail('Guest request expired',404);
 if(b.action==='approve'&&g.status!=='waiting')fail('Guest is no longer waiting',409);
 const status=b.action==='approve'?'approved':b.action==='reject'?'rejected':'removed';
 await env.DB!.batch([
  env.DB!.prepare('UPDATE meeting_guests SET status=? WHERE id=? AND meeting=?').bind(status,g.id,m.id),
  env.DB!.prepare("DELETE FROM meeting_presence WHERE meeting=? AND member=? AND ?<>'approved'").bind(m.id,g.id,status)
 ]);return json({ok:true});
}
export async function publicGuestRoute(req:Request,base='/ActivityTAB'){
 try{
  const u=new URL(req.url),method=req.method,path=u.pathname.replace(/^.*\/guest-api\/?/,'');
  if(method!=='GET'&&req.headers.get('origin')!==u.origin)fail('Invalid request origin',403);
  if(path==='join'&&method==='POST'){
   const b:any=await req.json(),raw=String(b.invite||''),name=String(b.name||'').trim().replace(/[\u0000-\u001f\u007f]/g,'').slice(0,80);
   if(!/^[a-f0-9]{64}$/.test(raw)||!name)fail('Enter your name and open a valid guest invitation');
   const m=await one("SELECT m.* FROM meetings m JOIN meeting_guest_links l ON l.meeting=m.id WHERE l.token=? AND l.enabled=1 AND m.kind='online' AND m.status='scheduled'",await guestHash(raw));
   if(!m)fail('This guest invitation is unavailable',404);
   if(Date.parse(m.end)<=Date.now()||Date.parse(m.start)>Date.now()+900000)fail('Guests can request entry from 15 minutes before the meeting until its scheduled end');
   const existing=(req.headers.get('cookie')||'').match(/(?:^|;\s*)activitytab_guest=([a-f0-9]{64})(?:;|$)/)?.[1];
   if(existing){const g=await one("SELECT id FROM meeting_guests WHERE token=? AND meeting=? AND expires>? AND status IN ('waiting','approved')",await guestHash(existing),m.id,Date.now());if(g)return json({ok:true})}
   const secret=guestSecret(),expires=Date.parse(m.end),gid='guest_'+id();
   const inserted=await run("INSERT INTO meeting_guests(id,meeting,name,token,status,expires,created) SELECT ?,?,?,?,'waiting',?,? WHERE (SELECT COUNT(*) FROM meeting_guests WHERE meeting=? AND expires>?)<40",gid,m.id,name,await guestHash(secret),expires,now(),m.id,Date.now());
   if(!inserted.meta.changes)fail('The waiting room is full. Contact the meeting host.',429);
   const response=json({ok:true});response.headers.set('Set-Cookie',`activitytab_guest=${secret}; Path=${base}/guest-api/; HttpOnly; SameSite=Strict; ${u.protocol==='https:'?'Secure; ':''}Max-Age=${Math.max(1,Math.ceil((expires-Date.now())/1000))}`);return response;
  }
  const secret=(req.headers.get('cookie')||'').match(/(?:^|;\s*)activitytab_guest=([a-f0-9]{64})(?:;|$)/)?.[1];
  if(!secret)fail('Open your invitation and request entry first',401);
  const g=await one("SELECT g.*,m.title,m.host,m.start,m.end,m.auto_record,m.status AS meeting_status,l.enabled,l.token AS link_token FROM meeting_guests g JOIN meetings m ON m.id=g.meeting JOIN meeting_guest_links l ON l.meeting=g.meeting WHERE g.token=? AND g.expires>?",await guestHash(secret!),Date.now());
  if(!g||await guestHash(req.headers.get('x-guest-invite')||'')!==g.link_token||!g.enabled||g.meeting_status!=='scheduled'||Date.parse(g.end)<=Date.now())fail('This guest session has ended',403);
  if(['rejected','removed'].includes(g.status))fail(g.status==='rejected'?'The host declined your entry request':'The host ended your guest access',403);
  if(path==='session'&&method==='GET')return json({status:g.status,me:{id:g.id,name:g.name},meeting:{id:g.meeting,title:g.title,host:g.host,start:g.start,end:g.end,auto_record:g.auto_record,members:[],recordings:[],people:g.status==='approved'?await meetingPeople(g.meeting):[]}});
  if(g.status!=='approved')fail('Please wait for the host to approve your entry',403);
  // Guest credentials are deliberately incapable of reaching tasks, notes, files, recordings or employee accounts.
  if(!/^(rtc|live|presence|signals)$/.test(path))fail('Not found',404);
  return await meetingsRoute(req,'meetings/'+g.meeting+'/'+path,{id:g.id,name:g.name,guestMeeting:g.meeting});
 }catch(e:any){return json({error:e.status?e.message:'Unable to process guest request'},e.status||500)}
}
