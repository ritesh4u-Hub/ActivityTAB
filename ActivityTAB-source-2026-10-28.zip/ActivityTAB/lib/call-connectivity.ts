// Verify traffic through two relay-only peers, without requesting camera or microphone.
export async function checkCallRelay(iceServers:RTCIceServer[],timeoutMs=12000){
 const peers=[new RTCPeerConnection({iceServers,iceTransportPolicy:'relay'}),new RTCPeerConnection({iceServers,iceTransportPolicy:'relay'})];
 const pending:RTCIceCandidateInit[][]=[[],[]];let timer:ReturnType<typeof setTimeout>|undefined;
 try{
  await new Promise<void>((resolve,reject)=>{
   let settled=false;const finish=(error?:Error)=>{if(settled)return;settled=true;clearTimeout(timer);error?reject(error):resolve()};
   timer=setTimeout(()=>finish(Error('Relay traffic timed out. Check firewall ports and the relay address.')),timeoutMs);
   for(let i=0;i<2;i++){
    const target=peers[1-i];peers[i].onicecandidate=e=>{if(!e.candidate||settled)return;const candidate=e.candidate.toJSON();if(target.remoteDescription)void target.addIceCandidate(candidate).catch(()=>finish(Error('Relay candidate exchange failed.')));else pending[1-i].push(candidate)};
    peers[i].onconnectionstatechange=()=>{if(peers[i].connectionState==='failed')finish(Error('Relay connection failed. Check the network and firewall.'))};
   }
   peers[1].ondatachannel=e=>{e.channel.onmessage=message=>{if(message.data==='activitytab-relay-check')e.channel.send('activitytab-relay-ok')}};
   const channel=peers[0].createDataChannel('activitytab-connectivity');channel.onopen=()=>channel.send('activitytab-relay-check');channel.onmessage=e=>{if(e.data==='activitytab-relay-ok')finish()};channel.onerror=()=>finish(Error('Relay data channel failed.'));
   void (async()=>{
    await peers[0].setLocalDescription(await peers[0].createOffer());await peers[1].setRemoteDescription(peers[0].localDescription!);
    for(const candidate of pending[1].splice(0))await peers[1].addIceCandidate(candidate);
    await peers[1].setLocalDescription(await peers[1].createAnswer());await peers[0].setRemoteDescription(peers[1].localDescription!);
    for(const candidate of pending[0].splice(0))await peers[0].addIceCandidate(candidate);
   })().catch(()=>finish(Error('Relay negotiation failed.')));
  });
 }finally{clearTimeout(timer);for(const pc of peers){pc.onicecandidate=null;pc.onconnectionstatechange=null;pc.close()}}
}
