import {env} from 'cloudflare:workers';
import {meetingRtc} from './rtc';
import {manageMeetingGuests,meetingPeople} from './meeting-guests';
import {id,now,one,rows,run,notify,flushPush} from './service';
const fail=(message:string,status=400):never=>{throw Object.assign(Error(message),{status})};
const json=(data:any)=>Response.json(data,{headers:{'Cache-Control':'no-store'}});
export async function meetingNotice(m:any,title:string,unique:string){
 for(const p of await rows('SELECT member FROM meeting_members WHERE meeting=?',m.id)){
  const nid=unique+':'+p.member;
  // Persist the relationship before enqueuing deliveries, so push never loses its deep link.
  await run('INSERT OR IGNORE INTO notifications(id,recipient,task,title,body,created,meeting) SELECT ?,?,NULL,?,?,?,? WHERE EXISTS(SELECT 1 FROM members WHERE id=? AND active=1)',nid,p.member,title,m.title+' · '+new Date(m.start).toLocaleString('en-IN',{timeZone:'Asia/Kolkata'})+' IST',now(),m.id,p.member);
  for(const s of await rows('SELECT id FROM subscriptions WHERE recipient=?',p.member))await run("INSERT OR IGNORE INTO deliveries(id,subscription,notification,status,created) VALUES(?,?,?,'pending',?)",nid+':'+s.id,s.id,nid,now());
 }
}
export async function meetingReminders(){
 const stamp=now();
 for(const photo of await rows('SELECT id FROM retired_photos WHERE retired<? LIMIT 20',new Date(Date.now()-172800000).toISOString())){if(!await one('SELECT id FROM members WHERE photo=?',photo.id)){await env.BUCKET?.delete(photo.id);await run('DELETE FROM retired_photos WHERE id=?',photo.id)}}
 const due=await rows("SELECT * FROM meetings WHERE status='scheduled' AND end>? AND start<=? AND julianday(start)-julianday(?)<=reminder/1440.0 AND NOT EXISTS(SELECT 1 FROM notifications n WHERE n.meeting=meetings.id AND n.id LIKE ('meeting-reminder:'||meetings.id||':'||meetings.start||':%')) LIMIT 200",stamp,new Date(Date.now()+1440*60000).toISOString(),stamp);
 for(const m of due)await meetingNotice(m,(m.kind==='online'?'Meeting':'Offline meeting')+' starts soon','meeting-reminder:'+m.id+':'+m.start);
 await run('DELETE FROM meeting_signals WHERE created<?',new Date(Date.now()-120000).toISOString());
 await run("UPDATE meeting_recordings SET status='interrupted' WHERE status='recording' AND updated<?",new Date(Date.now()-60000).toISOString());
}
export async function meetingsRoute(req:Request,path:string,me:any){
 const method=req.method,u=new URL(req.url),parts=path.split('/');
 if(path==='profile/photo'){
  if(method==='DELETE'){const old=(await one('SELECT photo FROM members WHERE id=?',me.id))?.photo;await run('UPDATE members SET photo=NULL WHERE id=?',me.id);if(old)await run('INSERT OR IGNORE INTO retired_photos VALUES(?,?)',old,now());return json({ok:true})}
  if(method!=='POST')fail('Not found',404);
  const file=(await req.formData()).get('file') as File;
  if(!file?.size||file.size>256*1024)fail('Choose a photo up to 256 KB');
  const bytes=new Uint8Array(await file.arrayBuffer());
  if(bytes[0]!==255||bytes[1]!==216||bytes[2]!==255)fail('Photo must be a JPEG image');
  const fid=id();await env.BUCKET!.put(fid,bytes);const old=(await one('SELECT photo FROM members WHERE id=?',me.id))?.photo;
  await run('UPDATE members SET photo=? WHERE id=?',fid,me.id);if(old)await run('INSERT OR IGNORE INTO retired_photos VALUES(?,?)',old,now());return json({ok:true});
 }
 if(parts[0]==='photos'&&method==='GET'){
  if(!await one('SELECT id FROM members WHERE photo=? AND active=1',parts[1]))fail('Photo not found',404);
  const f=await env.BUCKET?.get(parts[1]);if(!f)fail('Photo not found',404);
  return new Response(f!.body,{headers:{'Content-Type':'image/jpeg','Cache-Control':'private,max-age=86400','X-Content-Type-Options':'nosniff'}});
 }
 if(path==='availability'&&method==='GET'){
  const member=u.searchParams.get('member'),day=u.searchParams.get('day')||'';
  if(!/^\d{4}-\d{2}-\d{2}$/.test(day)||!await one('SELECT id FROM members WHERE id=? AND active=1',member))fail('Choose an employee and a valid date');
  const start=new Date(day+'T00:00:00+05:30'),end=new Date(+start+86400000);
  if(!Number.isFinite(+start)||new Date(+start+330*60000).toISOString().slice(0,10)!==day)fail('Invalid date');
  // Deliberately no ID, title, organiser, kind, notes, or participant information.
  return json({slots:await rows("SELECT m.start,m.end FROM meetings m JOIN meeting_members p ON p.meeting=m.id WHERE p.member=? AND m.status='scheduled' AND m.start<? AND m.end>? ORDER BY m.start",member,end.toISOString(),start.toISOString())});
 }
 if(path==='meetings'&&method==='GET'){
  const scope=u.searchParams.get('scope')||'upcoming',forward=scope==='upcoming',cursor=u.searchParams.get('cursor')||(forward?'':'9999'),limit=30;
  const condition=scope==='cancelled'?"m.status='cancelled'":scope==='past'?"m.status='scheduled' AND m.end<?":"m.status='scheduled' AND m.end>=?";
  const list=await rows(`SELECT m.id,m.title,m.kind,m.owner,m.host,m.start,m.end,m.status, (SELECT COUNT(*) FROM meeting_members a WHERE a.meeting=m.id) AS participants FROM meetings m JOIN meeting_members p ON p.meeting=m.id WHERE p.member=? AND ${condition} AND (m.start||m.id)${forward?'>':'<'}? ORDER BY m.start ${forward?'ASC':'DESC'},m.id ${forward?'ASC':'DESC'} LIMIT ?`,me.id,...(scope==='cancelled'?[]:[now()]),cursor,limit+1);
  const more=list.length>limit;if(more)list.pop();return json({meetings:list,next:more?list.at(-1).start+list.at(-1).id:null});
 }
 if(path==='meetings'&&method==='POST'){
  const b:any=await req.json(),title=String(b.title||'').trim(),start=new Date(b.start),end=new Date(b.end),kind=b.kind==='offline'?'offline':'online';
  if(!title||title.length>160||!Number.isFinite(+start)||!Number.isFinite(+end)||+end<=+start||+end-+start>86400000||+start<Date.now()-60000)fail('Enter a title and a future time range up to 24 hours');
  const members=[...new Set<string>([me.id,...(Array.isArray(b.members)?b.members.map(String):[])])];
  if(members.length>(kind==='online'?8:100))fail(kind==='online'?'Local video preview supports up to 8 participants':'Choose up to 100 participants');
  for(const member of members)if(!await one('SELECT id FROM members WHERE id=? AND active=1',member))fail('Choose active employees');
  const reminder=Number(b.reminder??15);if(![0,5,15,30,60,1440].includes(reminder))fail('Invalid reminder');
  const mid=id(),stamp=now(),marks=members.map(()=>'?').join(',');
  // Atomic INSERT prevents double booking even when two organisers save concurrently.
  const insert=env.DB!.prepare(`INSERT INTO meetings(id,title,description,kind,location,owner,host,start,end,reminder,auto_record,created,updated) SELECT ?,?,?,?,?,?,?,?,?,?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM meetings m JOIN meeting_members p ON p.meeting=m.id WHERE m.status='scheduled' AND p.member IN (${marks}) AND m.start<? AND m.end>?)`).bind(mid,title,String(b.description||'').slice(0,4000),kind,String(b.location||'').slice(0,300),me.id,me.id,start.toISOString(),end.toISOString(),reminder,kind==='online'&&b.autoRecord?1:0,stamp,stamp,...members,end.toISOString(),start.toISOString());
  const result=await env.DB!.batch([insert,...members.map(member=>env.DB!.prepare('INSERT INTO meeting_members(meeting,member) SELECT ?,? WHERE EXISTS(SELECT 1 FROM meetings WHERE id=?)').bind(mid,member,mid))]);
  if(!result[0].meta.changes)fail('One or more participants are already busy in this time slot. Choose another time.',409);
  const meeting=await one('SELECT * FROM meetings WHERE id=?',mid);await meetingNotice(meeting,kind==='online'?'Meeting invitation':'Offline meeting scheduled','meeting-created:'+mid);void flushPush().catch(()=>{});return json({id:mid});
 }
 if(parts[0]!=='meetings'||!parts[1])fail('Not found',404);
 const mid=parts[1];
 if(me.guestMeeting&&(me.guestMeeting!==mid||!['rtc','live','presence','signals'].includes(parts[2])||parts.length!==3))fail('Not found',404);
 const m=me.guestMeeting?await one("SELECT m.* FROM meetings m JOIN meeting_guests g ON g.meeting=m.id JOIN meeting_guest_links l ON l.meeting=m.id WHERE m.id=? AND g.id=? AND g.status='approved' AND g.expires>? AND l.enabled=1",mid,me.id,Date.now()):await one('SELECT m.* FROM meetings m JOIN meeting_members p ON p.meeting=m.id WHERE m.id=? AND p.member=?',mid,me.id);
 if(!m)fail('Meeting not found or you are not invited',404);
 if(parts[2]==='guests'&&parts.length===3)return manageMeetingGuests(req,m,me);
 if(parts[2]==='rtc'&&method==='GET'){
  if(m.kind!=='online'||m.status!=='scheduled'||+new Date(m.end)<Date.now()||+new Date(m.start)>Date.now()+900000)fail('Relay credentials are available only during the meeting join window');
  return json(await meetingRtc(m,me.id));
 }
 if(parts[2]==='live'&&method==='GET')return json({id:m.id,host:m.host,status:m.status,auto_record:m.auto_record,people:await meetingPeople(mid),presence:await rows('SELECT member,session,seen FROM meeting_presence WHERE meeting=? AND seen>?',mid,new Date(Date.now()-20000).toISOString()),recordings:await rows("SELECT id,status FROM meeting_recordings WHERE meeting=? AND status='recording' LIMIT 1",mid)});
 if(parts.length===2&&method==='GET'){
  const members=await rows('SELECT p.member FROM meeting_members p WHERE p.meeting=?',mid);
  return json({...m,members:members.map(p=>p.member),recordings:await rows("SELECT id,mime,status,created,recorder FROM meeting_recordings WHERE meeting=? ORDER BY created DESC LIMIT 20",mid),presence:await rows('SELECT member,session,seen FROM meeting_presence WHERE meeting=? AND seen>?',mid,new Date(Date.now()-20000).toISOString())});
 }
 if(parts.length===2&&method==='PATCH'){
  const b:any=await req.json();if(m.status==='cancelled')fail('Meeting is cancelled');
  if(b.action==='notes'){
   if(String(b.notes||'').length>30000)fail('Notes must be under 30,000 characters');
   const changed=await run('UPDATE meetings SET notes=?,notes_version=notes_version+1,updated=? WHERE id=? AND notes_version=?',String(b.notes||''),now(),mid,Number(b.version));if(!changed.meta.changes)fail('Another participant updated the notes. Reload before saving.',409);
  }else if(b.action==='shareNotes'){
   if(m.host!==me.id&&m.owner!==me.id)fail('Host access required',403);
   await meetingNotice(m,'Meeting notes available','meeting-notes:'+mid+':'+m.notes_version);void flushPush().catch(()=>{});
  }else if(b.action==='host'){
   if(m.host!==me.id)fail('Only the current host can transfer control',403);
   if(!await one('SELECT p.member FROM meeting_members p JOIN members a ON a.id=p.member WHERE p.meeting=? AND p.member=? AND a.active=1',mid,b.member))fail('Choose an invited employee');
   await run('UPDATE meetings SET host=?,updated=? WHERE id=? AND host=?',b.member,now(),mid,me.id);
  }else if(b.action==='cancel'){
   if(m.owner!==me.id)fail('Only the organiser can cancel',403);
   await run("UPDATE meetings SET status='cancelled',updated=? WHERE id=?",now(),mid);await meetingNotice(m,'Meeting cancelled','meeting-cancelled:'+mid);void flushPush().catch(()=>{});
  }else fail('Unknown action');return json({ok:true});
 }
 if(parts[2]==='presence'&&method==='POST'){
  const b:any=await req.json();if(b.leave){await run('DELETE FROM meeting_presence WHERE meeting=? AND member=? AND session=?',mid,me.id,String(b.session));return json({ok:true})}
  if(m.kind!=='online'||m.status!=='scheduled'||+new Date(m.end)<Date.now()||+new Date(m.start)>Date.now()+15*60000)fail('Join from 15 minutes before the meeting until its scheduled end');
  if(!/^[\w-]{8,80}$/.test(b.session||''))fail('Invalid call session');
  const cutoff=new Date(Date.now()-20000).toISOString();
  const joined=await run('INSERT INTO meeting_presence(meeting,member,session,seen) SELECT ?,?,?,? WHERE EXISTS(SELECT 1 FROM meeting_presence WHERE meeting=? AND member=? AND seen>?) OR (SELECT COUNT(*) FROM meeting_presence WHERE meeting=? AND seen>?)<8 ON CONFLICT(meeting,member) DO UPDATE SET session=excluded.session,seen=excluded.seen',mid,me.id,b.session,now(),mid,me.id,cutoff,mid,cutoff);
  if(!joined.meta.changes)fail('This call already has eight participants. Wait for someone to leave.',409);
  return json({ok:true});
 }
 if(parts[2]==='signals'){
  if(m.kind!=='online'||m.status!=='scheduled'||Date.parse(m.end)<Date.now())fail('Call unavailable');
  const session=u.searchParams.get('session')||'';
  if(method==='GET'){
   if(!await one('SELECT member FROM meeting_presence WHERE meeting=? AND member=? AND session=? AND seen>?',mid,me.id,session,new Date(Date.now()-20000).toISOString()))fail('Call session expired',409);
   return json({signals:await rows('SELECT seq,sender,sender_session,payload FROM meeting_signals WHERE meeting=? AND recipient=? AND session=? AND seq>? ORDER BY seq LIMIT 100',mid,me.id,session,Number(u.searchParams.get('after'))||0)});
  }
  if(method==='POST'){
   const b:any=await req.json(),payload=JSON.stringify(b.payload);
   if(payload.length>32000||!['offer','answer','ice'].includes(b.payload?.type))fail('Invalid signal');
   const cutoff=new Date(Date.now()-20000).toISOString();
   if(!await one('SELECT member FROM meeting_presence WHERE meeting=? AND member=? AND session=? AND seen>?',mid,me.id,b.session,cutoff))fail('Call session expired',409);
   const peer=await one('SELECT member FROM meeting_presence WHERE meeting=? AND member=? AND session=? AND seen>?',mid,b.recipient,b.peerSession,cutoff);if(!peer)fail('Participant left the call',409);
   if((await one('SELECT COUNT(*) n FROM meeting_signals WHERE meeting=? AND sender=? AND created>?',mid,me.id,new Date(Date.now()-60000).toISOString())).n>=600)fail('Call signaling is busy. Please rejoin shortly.',429);
   await run('INSERT INTO meeting_signals(meeting,sender,recipient,session,sender_session,payload,created) VALUES(?,?,?,?,?,?,?)',mid,me.id,b.recipient,b.peerSession,b.session,payload,now());return json({ok:true});
  }
 }
 if(parts[2]==='recordings'){
  if(parts.length===3&&method==='POST'){
   if(m.host!==me.id||m.kind!=='online'||m.status!=='scheduled')fail('Only the current meeting host can record',403);
   if(!await one('SELECT member FROM meeting_presence WHERE meeting=? AND member=? AND seen>?',mid,me.id,new Date(Date.now()-20000).toISOString()))fail('Join the call first');
   if(await one("SELECT id FROM meeting_recordings WHERE meeting=? AND status='recording' AND updated>?",mid,new Date(Date.now()-60000).toISOString()))fail('A recording is already in progress',409);
   const b:any=await req.json();if(!['video/webm','video/mp4'].includes(b.mime))fail('Unsupported recording format');
   await run("UPDATE meeting_recordings SET status='interrupted' WHERE meeting=? AND status='recording' AND updated<?",mid,new Date(Date.now()-60000).toISOString());const rid=id();const inserted=await run("INSERT INTO meeting_recordings(id,meeting,recorder,mime,status,created,updated) SELECT ?,?,?,?,'recording',?,? WHERE NOT EXISTS(SELECT 1 FROM meeting_recordings WHERE meeting=? AND status='recording')",rid,mid,me.id,b.mime,now(),now(),mid);if(!inserted.meta.changes)fail('A recording is already in progress',409);return json({id:rid});
  }
  const r=await one('SELECT * FROM meeting_recordings WHERE id=? AND meeting=?',parts[3],mid);if(!r)fail('Recording not found',404);
  if(method==='GET'){
   const chunks=await rows('SELECT file FROM meeting_recording_parts WHERE recording=? ORDER BY part',r.id);
   let pos=0,current:ReadableStreamDefaultReader|undefined;
   const stream=new ReadableStream({async pull(controller){try{while(true){if(!current){if(pos>=chunks.length){controller.close();return}const file=await env.BUCKET!.get(chunks[pos++].file);if(!file)throw Error('Recording part missing');current=file.body.getReader()}
    const v=await current.read();if(v.done){current=undefined;continue}controller.enqueue(v.value);return}}catch(e){controller.error(e)}},cancel(){return current?.cancel()}});
   return new Response(stream,{headers:{'Content-Type':r.mime,'Content-Disposition':'attachment; filename="meeting-recording.'+(r.mime==='video/mp4'?'mp4':'webm')+'"','Cache-Control':'private,no-store','X-Content-Type-Options':'nosniff'}});
  }
  if(r.recorder!==me.id)fail('Recorder access required',403);
  if(method==='PATCH'){const b:any=await req.json();await run('UPDATE meeting_recordings SET status=?,updated=? WHERE id=?',b.complete?'complete':'interrupted',now(),r.id);return json({ok:true})}
  if(method==='POST'){
   if(r.status!=='recording')fail('Recording has ended');
   const part=Number(u.searchParams.get('part'));if(!Number.isInteger(part)||part<0||part>20000)fail('Invalid recording part');
   const bytes=await req.arrayBuffer();if(!bytes.byteLength||bytes.byteLength>5*1024*1024)fail('Recording chunks must be under 5 MB');
   const existing=await one('SELECT file FROM meeting_recording_parts WHERE recording=? AND part=?',r.id,part);if(existing)return json({ok:true});
   const fid=id();await env.BUCKET!.put(fid,bytes);try{await run('INSERT INTO meeting_recording_parts(recording,part,file,size) VALUES(?,?,?,?)',r.id,part,fid,bytes.byteLength)}catch(e){await env.BUCKET!.delete(fid);throw e}
   await run('UPDATE meeting_recordings SET updated=? WHERE id=?',now(),r.id);return json({ok:true});
  }
 }
 fail('Not found',404);
}
