import {reminderCandidates} from './reminder-candidates';
import {meetingReminders} from './meetings';
import {relatedToTask,notificationVisibility} from './task-access';
import {reminderIsRelevant,retryDelay} from './notification-policy';
import {nextScheduledDue,isWorkingDay} from './recurrence';
import {env} from 'cloudflare:workers';
import {generateVapid,sendPush} from './push';
export const now=()=>new Date().toISOString();
export const id=()=>crypto.randomUUID();
export const defaults={beforeHours:24,repeatHours:24,escalateHours:48,workStart:9,workEnd:18,weekdaysOnly:true,includeSaturday:false,holidays:[],timeZone:'Asia/Kolkata'};
export const db=()=>{if(!env.DB)throw Error('Database is unavailable');return env.DB};
export async function rows(sql:string,...args:any[]){return (await db().prepare(sql).bind(...args).all()).results as any[]}
export async function one(sql:string,...args:any[]){return await db().prepare(sql).bind(...args).first() as any}
export async function run(sql:string,...args:any[]){return await db().prepare(sql).bind(...args).run()}
export async function setting(key:string,fallback:any=null){const r=await one('SELECT value FROM settings WHERE key=?',key);return r?JSON.parse(r.value):fallback}
export async function saveSetting(key:string,value:any){await run('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',key,JSON.stringify(value))}
export async function audit(task:string,actor:string,message:string){await run('INSERT INTO events(id,task,actor,message,created) VALUES(?,?,?,?,?)',id(),task,actor,message,now())}
export async function vapid(){const current=await setting('vapid');if(current)return current;const generated=await generateVapid();await run('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)','vapid',JSON.stringify(generated));return await setting('vapid')}
export async function notify(recipient:string,task:string|null,title:string,body:string,unique?:string,onlySubscription?:string){if(!(await one('SELECT active FROM members WHERE id=?',recipient))?.active)return;if(task&&!relatedToTask(await one('SELECT * FROM tasks WHERE id=?',task),recipient))return;const nid=unique||id();await run('INSERT OR IGNORE INTO notifications(id,recipient,task,title,body,created) VALUES(?,?,?,?,?,?)',nid,recipient,task,title,body,now());const subs=await rows('SELECT * FROM subscriptions WHERE recipient=?',recipient);for(const s of subs)if(!onlySubscription||s.id===onlySubscription)await run('INSERT OR IGNORE INTO deliveries(id,subscription,notification,status,created) VALUES(?,?,?,?,?)',nid+':'+s.id,s.id,nid,'pending',now());}
// Grant access only when an overdue escalation is actually sent.
export async function escalateTask(task:any,actor:string,note:string,manual=false,repeatHours=24){
 if(!task?.escalation_manager)return false;
 const recipient=await one("SELECT id,name FROM members WHERE id=? AND active=1 AND role IN ('admin','manager')",task.escalation_manager);if(!recipient)return false;
 const stamp=now(),cutoff=new Date(Date.now()-(manual?5/60:repeatHours)*3600000).toISOString();
 const changed=await run("UPDATE tasks SET escalated_at=? WHERE id=? AND escalation_manager=? AND due=? AND due<? AND status IN ('pending','progress','returned') AND (escalated_at IS NULL OR escalated_at<=?)",stamp,task.id,recipient.id,task.due,stamp,cutoff);if(!changed.meta.changes)return false;
 await audit(task.id,actor,'Escalated overdue task to '+recipient.name+(note?': '+note:''));
 await notify(recipient.id,task.id,'Overdue escalation: '+task.title,note||'This task is overdue and needs your attention. Open it to review the deadline, documents and activity.','escalation:'+task.id+':'+task.due+':'+recipient.id+':'+stamp);
 return true;
}
let pushBusy=false;
export async function flushPush(){
 if(pushBusy)return;pushBusy=true;
 try{
 await run("UPDATE deliveries SET status=CASE WHEN attempts>=4 THEN 'failed' ELSE 'pending' END WHERE status='sending' AND updated<?",new Date(Date.now()-300000).toISOString());
 await run("UPDATE deliveries SET status='superseded',error='Device account changed or disconnected' WHERE status IN ('pending','sending') AND NOT EXISTS (SELECT 1 FROM subscriptions s JOIN notifications n ON n.id=deliveries.notification WHERE s.id=deliveries.subscription AND s.recipient=n.recipient)");
 const jobs=await rows("SELECT d.*,s.data,n.title,n.body,n.task,n.recipient,n.conversation,n.meeting,n.read FROM deliveries d JOIN subscriptions s ON s.id=d.subscription JOIN notifications n ON n.id=d.notification JOIN members m ON m.id=n.recipient WHERE m.active=1 AND s.recipient=n.recipient AND d.status='pending' AND d.attempts<4 AND (d.next_attempt IS NULL OR d.next_attempt<=?) ORDER BY d.created LIMIT 50",now());
 if(!jobs.length)return;const key=await vapid();
 const send=async(j:any)=>{
  if(j.meeting){const allowed=await one('SELECT m.status,m.start FROM meetings m JOIN meeting_members p ON p.meeting=m.id WHERE m.id=? AND p.member=?',j.meeting,j.recipient);if(!allowed||j.read||(j.notification.startsWith('meeting-reminder:')&&(allowed.status!=='scheduled'||allowed.start<now()))){await run("UPDATE deliveries SET status='superseded',error='Meeting access or reminder changed' WHERE id=?",j.id);return}}
  if(j.conversation){const member=await one('SELECT cm.muted,c.task FROM chat_members cm JOIN conversations c ON c.id=cm.conversation WHERE cm.conversation=? AND cm.member=?',j.conversation,j.recipient);const task=member?.task?await one('SELECT * FROM tasks WHERE id=?',member.task):null;if(j.read||!member||member.muted||(member.task&&!relatedToTask(task,j.recipient))){await run("UPDATE deliveries SET status='superseded',error='Conversation read, muted or access changed' WHERE id=? AND status='pending'",j.id);return}}
  const t=j.task?await one('SELECT * FROM tasks WHERE id=?',j.task):null;
  if(j.task&&!relatedToTask(t,j.recipient)){await run("UPDATE deliveries SET status='superseded',error='Task access changed' WHERE id=? AND status='pending'",j.id);return}
  if(!reminderIsRelevant(j.notification,t)){await run("UPDATE deliveries SET status='superseded',error='Task state or deadline changed' WHERE id=? AND status='pending'",j.id);return}
  const claimed=await run("UPDATE deliveries SET status='sending',attempts=attempts+1,updated=? WHERE id=? AND status='pending' AND EXISTS (SELECT 1 FROM subscriptions s WHERE s.id=subscription AND s.recipient=?)",now(),j.id,j.recipient);if(!claimed.meta.changes)return;
  try{
   const visible=notificationVisibility(j.recipient);
   const result=await sendPush(JSON.parse(j.data),{title:j.title,body:j.body,url:j.meeting?'/?meeting='+encodeURIComponent(j.meeting):j.conversation?'/?chat='+encodeURIComponent(j.conversation):j.task?'/?task='+j.task:'/',tag:j.notification,unreadCount:(await one('SELECT COUNT(*) n FROM notifications n WHERE n.recipient=? AND n.read=0 AND '+visible.sql,j.recipient,...visible.args)).n},key);
   if(result.status===404||result.status===410){await run('DELETE FROM subscriptions WHERE id=?',j.subscription);await run("UPDATE deliveries SET status='expired',error=? WHERE id=? AND status='sending'",String(result.status),j.id)}
   else{const retry=!result.ok&&(result.status===429||result.status>=500)&&j.attempts<3;await run("UPDATE deliveries SET status=?,error=?,next_attempt=? WHERE id=? AND status='sending'",result.ok?'sent':retry?'pending':'failed',result.ok?null:'Push service HTTP '+result.status,retry?new Date(Date.now()+retryDelay(j.attempts+1,result.retryAfter)).toISOString():null,j.id)}
  }catch(e){const retry=j.attempts<3;await run("UPDATE deliveries SET status=?,error=?,next_attempt=? WHERE id=? AND status='sending'",retry?'pending':'failed',String(e).slice(0,200),retry?new Date(Date.now()+retryDelay(j.attempts+1)).toISOString():null,j.id)}
 };
 for(let i=0;i<jobs.length;i+=4)await Promise.all(jobs.slice(i,i+4).map(send));
 }finally{pushBusy=false}
}
export async function maintenance(options:{flush?:boolean}={}){const lock=await run("INSERT INTO settings(key,value) VALUES('tick-lock',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value WHERE CAST(settings.value AS INTEGER)<?",String(Date.now()),Date.now()-300000);if(!lock.meta.changes)return {busy:true};try{const config=await setting('reminders',defaults);let generated=0;for(let pass=0;pass<10;pass++){const due=await rows("SELECT * FROM tasks WHERE frequency!='once' AND next_created=0 AND due<=? LIMIT 100",now());if(!due.length)break;for(const t of due){const root=t.parent||t.id;const original=await one('SELECT due FROM tasks WHERE id=?',root);const anchor=new Date(new Date(original?.due||t.due).getTime()+330*60000).getUTCDate();const next=nextScheduledDue(t.due,t.frequency,anchor,config);
const tid=root+'_'+next;await run('INSERT OR IGNORE INTO tasks(id,title,description,assignee,creator,due,priority,status,frequency,required,approval,parent,created,escalation_manager,escalation_hours) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',tid,t.title,t.description,t.assignee,t.creator,next,t.priority,'pending',t.frequency,t.required,t.approval,root,now(),t.escalation_manager||null,t.escalation_hours||null);await run('UPDATE tasks SET next_created=1 WHERE id=?',t.id);await notify(t.assignee,tid,'Recurring task: '+t.title,'Your next task is ready.','recurring:'+tid);generated++}}
const local=new Date(Date.now()+330*60000);let reminders=0;const working=local.getUTCHours()>=config.workStart&&local.getUTCHours()<config.workEnd&&isWorkingDay(new Date(),config);if(working){const candidates=reminderCandidates(now(),config);const active=await rows(candidates.sql,...candidates.args);for(const t of active){const late=(Date.now()-new Date(t.due).getTime())/3600000;if(t.status==='submitted'){const waiting=(Date.now()-new Date(t.submitted).getTime())/3600000;if(waiting>=config.repeatHours)await notify(t.creator,t.id,'Review pending: '+t.title,'A submitted task is waiting for your review.','review:'+t.id+':'+t.submitted+':'+Math.floor(waiting/config.repeatHours));continue}if(late>=0){if(t.escalation_manager&&late>=(t.escalation_hours||config.escalateHours))await escalateTask(t,'ActivityTAB','',false,config.repeatHours);await notify(t.assignee,t.id,'Overdue: '+t.title,'Please complete and submit this task.','late:'+t.id+':'+t.due+':'+Math.floor(late/config.repeatHours));reminders++;if(late>=config.escalateHours)await notify(t.creator,t.id,'Escalation: '+t.title,'This task is overdue and requires your attention.','escalation:'+t.id+':'+t.due+':'+Math.floor(late/config.repeatHours))}else if(-late<=config.beforeHours){await notify(t.assignee,t.id,'Due soon: '+t.title,'Your task deadline is approaching.','before:'+t.id+':'+t.due);reminders++}}}await meetingReminders();if(options.flush!==false)await flushPush();await saveSetting('lastTick',now());return {generated,reminders,lastRun:now()}}finally{await run("DELETE FROM settings WHERE key='tick-lock'")}}
