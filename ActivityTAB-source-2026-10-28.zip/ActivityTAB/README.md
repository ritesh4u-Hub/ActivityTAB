# ActivityTAB

## Current Windows deployment

The live deployment is https://mis-sweetdreams.in/ActivityTAB/ on Windows IIS, with the Node runtime in `windows/`. Build with `node windows/build.mjs`. Windows uses local email/password authentication, private SQLite/uploads, a minute scheduler and a separate push retry worker. The Sites sections below describe the original hosting variant.

Public holidays support inclusive From/To date entry, grouped ranges and single-day entries. Each covered date is stored using the existing daily holiday format, with overlap validation and a total limit of 100 dates. Reminder interval inputs can be cleared and replaced before saving.

The Windows release includes private direct messages and fixed-membership team groups under Chat, plus discussions opened from Task details. Tasks, documents and task discussions are visible only to the assigning person and assigned executive, including for manager and administrator accounts. General administrative permissions do not grant access to unrelated tasks. General chats have no administrator override: only participants can read their messages and files. Completed tasks can share a summary and protected link through the mobile share sheet, email, WhatsApp or clipboard; attachments are not included and no access rights are changed. Groups do not yet support changing participants, message edits/deletion, mentions or voice/video calls.

Chat uses visible-page polling (messages every five seconds; conversation list every fifteen seconds), cursor-based message pages of 50, 5,000-character messages, a per-sender throttle and idempotent send identifiers. PDF, JPEG, PNG, Excel and CSV attachments are limited to 10 MB and downloaded through authenticated requests. Muting a conversation stops its push alerts while retaining unread messages. Notification taps open the specific chat. Push content identifies the conversation without exposing message text on the lock screen. Phone delivery still depends on permission, connectivity and OS settings. Push notifications request sound and vibration; notification tones, Silent mode and Do Not Disturb remain controlled by the phone.

Schema migrations are applied transactionally on Windows startup. The update script stops the process and preserves the old runtime, database/WAL and uploads in private storage before migration. Daily online database backups include both task documents and chat attachments; only verified completed backups count toward retention of 14. Off-server backups and external integrations are not configured.

Windows checks: `node windows/test.mjs` (disposable integration database), `node windows/notification-test.mjs` (isolated provider stub, no real pushes). Build before running these checks.


An installable task management web application for an internal team of about 100 employees.

## Included

- Administrator, manager, and executive permissions enforced on the server.
- Task assignments, deadlines, priorities, acknowledgements, and work status.
- Separate daily, weekly, and monthly occurrences. Month-end dates preserve the original day, with shorter months clamped. Daily tasks can skip weekends.
- Private Excel, CSV, PDF, and JPEG submissions (20 MB per file). PDFs and JPEGs open for review; spreadsheets download for review.
- Submit, approve, and return for correction with a new deadline. Returned tasks can be resubmitted with remarks using an existing attachment; a revised document is optional.
- In-app notifications, encrypted standards-based Web Push, VAPID authentication, delivery logs, expired subscription cleanup, and bounded retries.
- Configurable working hours, pre-deadline reminders, overdue repeats, and escalation to the assigning manager. All workday times use Asia/Kolkata.
- PWA manifest, Android/maskable/iPhone icons, service worker, offline fallback, install instructions, and test notifications.
- Search, status/priority filters, board/list views, a team directory, and document library.

## Sign-in and employee access

Sites supplies authenticated identity. The first visitor on the initially owner-private site becomes the administrator. Employees sign in with their ChatGPT account. Add an employee with that account's email under Team, and separately grant them access through the Sites access policy. Adding a database member does not send any email or change site access. The initial publication is owner-private.

This version is built for one organization. People can access only tasks they assigned or are assigned to, along with those tasks’ documents and discussions. The assigning manager reviews submissions. Administrators can manage employees and reminder settings. Deactivating an employee blocks access and push delivery without deleting history.

## Phone setup

Open the deployed URL on the phone. Install using Chrome's menu on Android or Safari's Share → Add to Home Screen on iPhone. iPhone push requires iOS 16.4 or later. Open the installed app, sign in, and use Settings → Enable notifications → Send test. The app requires an internet connection for reading and submitting work. The offline screen does not cache employee records or documents.

## Background processing

`POST /api/maintenance` generates recurring tasks, creates reminders, escalates overdue work, and retries push deliveries. New assignment and submission notifications are attempted immediately. Maintenance is intended to be called hourly through a linked Sites cloud schedule, with runtime service access supplied by Sites. Reminder timing has hourly granularity and follows configured working hours. Notifications are deduplicated by task/deadline/interval. The last successful check is shown in Settings.

The maintenance endpoint relies on the Sites private access boundary for unattended service calls. Preserve restricted Site access. If converting the Site to public, add an application-level service credential before doing so. Employee account membership is separately checked on all data APIs.

The linked schedule uses a self-contained request and does not need external source data. Each run retrieves the current Site's service access using the native get_site tool, POSTs to the deployed origin's `/api/maintenance` using `OAI-Sites-Authorization: Bearer <runtime token>`, and verifies the returned lastRun. The runtime token must never be written to source, automation prompts, command arguments, or logs. The scheduler is independent of an open browser or the author's laptop.

## Local development

Node 22.13+ and pnpm 11.25 are required.

1. `pnpm install`
2. `pnpm run build`
3. Apply the committed SQL migrations in order using the local D1 commands documented in the Sites starter skill. Use `.wrangler/state` as the persistence directory.
4. `pnpm run dev`
5. Follow the local sign-in link. Local mock sign-in uses `seedy@sites.test` and is excluded from the production build.

Publish through the Sites skill. `.openai/hosting.json` declares the DB and BUCKET bindings. Private task records and file contents remain in D1/R2 and are not in the source repository.

## Verification

- `pnpm exec tsc --noEmit`
- `node tests/recurrence.mjs`: daily/weekly recurrence, month-end recovery, leap years, and IST midnight.
- `node tests/web-push.mjs`: independently decrypts the outgoing Web Push payload and verifies the VAPID signature/audience; rejects untrusted endpoints.
- `node tests/integration.mjs`: 54 assertions against the built local Worker at port 8787. Covers role enforcement, task/document privacy, upload validation, submit/return/resubmit/approve, deactivation, recurring generation, reminder deduplication, and PWA assets. This creates test records and must only run against local test storage.
- Desktop and 390px mobile browser QA covers installation guidance, task creation, and task details.

Actual phone push delivery depends on device permission, connectivity, and operating-system settings. The app records service acceptance rather than claiming the user read the alert. Acknowledgement is a separate executive action.

### Local meetings and profile preview (not deployed)

The local branch adds employee-managed profile photos, private online/offline meetings, personal busy slots, conflict prevention, participant invitations/reminders, host transfer, manual shared notes and DOCX export/native sharing. Profile uploads are cropped to 256×256 JPEGs in the browser and limited to 256 KB at the API. Only participants may retrieve meeting details, signaling, notes or recordings; colleague availability returns start/end pairs only. Meetings use IST and each appointment is limited to 24 hours. Cancellation releases booked time. Notes use optimistic version checks to prevent silent overwrites.

The approved call size is eight including the host; the workforce capacity target is 300 employees. The local video implementation uses WebRTC with optional authenticated TURN relay configuration. The current Mac preview connects to an isolated Coturn 4.18.0 instance on loopback; public relay access is not configured. Calls across separate networks, firewall traversal, mobile screen capture and real multi-device audio/video/recording still require device/network validation before publication. Host-only screen-share controls and browser recording are implemented; a browser cannot guarantee that an altered participant client will obey a media-source restriction. A production media service should enforce presenter permissions. Recording starts after the host chooses a screen/tab, includes mixed call audio, displays an indicator, uploads bounded chunks and stops when that browser leaves. Interrupted uploads remain marked interrupted. This is browser recording, not server recording. Automatic transcription/minutes are deliberately excluded at the user's request. No OpenAI key is used.

### Performance safeguards and reproducible checks

Task, document, activity and notification responses are bounded to 100 records; meeting pages to 30; chat history to 50 messages per response and 300 rendered messages. Conversation lists have 50-record pages. Keyset cursors keep old records accessible without large OFFSET scans. SQL aggregates provide full-history dashboard counts independently of the loaded page. Full task instructions, files and events load on demand. Search uses FTS5 indexes maintained transactionally by triggers; task/document search matches word prefixes rather than arbitrary substrings. Queries always reapply employee relationship access controls, including searches and cursor requests. The initial UI uses `/state?lean=1` and omits document metadata.

Uploads have bounded concurrency and queue length, actual body-size limits and timeouts. Meeting recordings upload at most six pending chunks, stop on sustained upload failure, and download as authenticated streams rather than whole-file browser blobs. Profile photos use lazy loading and private versioned cache URLs. Recording and photo data are included in verified backups. Backup manifest verification uses a map rather than repeated linear scans. Push retries are bounded; scheduler task candidates exclude already-queued reminders and process at most 500 eligible tasks per tick, with 1,000 recurring instances and 200 meeting reminders per tick. A backlog can therefore delay reminders; scheduler health alone is not a backlog SLA.

Run with Node 24:

```
node windows/build.mjs
node node_modules/typescript/bin/tsc --noEmit
node windows/test.mjs
node windows/notification-test.mjs
node windows/meetings-test.mjs
node windows/performance-test.mjs
```

All integration/load tests create and remove isolated temporary databases; they do not mutate the company server or send external push notifications. The load fixture has 300 employees, 100,000 tasks, 50,000 document metadata records, 100,000 chat messages and 100,000 notifications. It tests 20 concurrent mixed reads, 299 authenticated employee sessions in bursts of 30, and two concurrent 20 MB document uploads. This measures local HTTP/database performance, not production hardware, cellular network latency, 300 simultaneous video participants or video quality. Storage retention, disk capacity and a production media relay/server must be planned before deployment; no software can promise constant latency at unlimited volume.

Further local optimisation removes duplicate initial task-page queries, uses disjoint relationship branches and covering indexes for counts and list ordering, indexes chat attachment lookup/unread counts, and moves password hashing to a bounded asynchronous queue. Cached static assets use gzip plus ETag revalidation and invalidate when deployed files change; service workers and authenticated HTML remain uncached. These changes preserve password hashing strength and task privacy.

Administrators can inspect Settings → Performance health: bounded recent latency samples, server errors, upload/password queues, event-loop delay, memory, database/WAL size and available disk. Metrics omit query strings and task/message contents. They are runtime observations, not a capacity guarantee. The application target is 300 registered employees and eight participants per call; scaling simultaneous calls needs separate media capacity planning.

Conversation unread counts are maintained transactionally with message/read/membership triggers, avoiding repeated scans of long chat histories. The migration backfills counters once; subsequent list requests read a stored per-member count.

### Coturn local verification

Coturn 4.18.0 and dependencies were downloaded from Homebrew's official GHCR packages, checked against published SHA-256 values, and relocated into ignored `work/coturn-runtime`. The original package sources/digests are recorded in `windows/coturn/local-package-provenance.json`; the local-only installer is `python3 scripts/install-coturn-local.py` (macOS Apple Silicon). It does not install Homebrew, modify global package paths or register a startup service. Runtime copies receive local ad-hoc signatures after library path relocation. The downloaded package payloads remain available for inspection.

The running local configuration binds TCP/UDP only to 127.0.0.1:3479, disables TLS for this loopback-only test, leaves DTLS/CLI/web-admin off, uses a private random shared secret, bounds relay ports/allocations/bandwidth, and denies private/multicast/loopback peers. A macOS sandbox denies user-home content access except the Coturn runtime, denies home writes except its run directory, denies user-temporary application data access and restricts outbound/bind networking to localhost. It is a local test sandbox, not a production container/service account. Application-folder read/write denial was verified with disposable probes. Do not copy the local no-TLS configuration into an Internet-facing service.

The application reads `ACTIVITYTAB_TURN_URLS` (comma-separated turn/turns URLs) and `ACTIVITYTAB_TURN_SECRET` only on the server. `/meetings/:id/rtc` checks active participant membership, cancellation and the join window before issuing a hashed-user/time-limited HMAC credential. The shared secret is not returned. Credentials expire in at most one hour or five minutes after meeting end, whichever comes first. The call refreshes relay configuration and initiates an ICE restart before expiry. Cancellation prevents new credentials; already-issued TURN credentials remain usable until their expiry. All API responses are no-store. No production credentials have been created or used.

`node windows/turn-relay-test.mjs` tests the local listener: rejects anonymous, incorrect and expired credentials; accepts an authenticated allocation; denies a permission request to a private loopback destination; releases the allocation. The app's call-lobby connectivity test also successfully gathered an authenticated relay candidate without camera/microphone access. This proves local allocation, not a completed multi-device video call or Internet traversal. The main Windows server, IIS and its application/database were not changed. Public rollout requires a reachable relay hostname, valid TLS certificate, firewall/egress rules, service isolation and real-device testing; relay capacity is separate from the 300-employee application target. Coturn is a connectivity relay, not an SFU or recording/transcription server.

Sign-in throttles use account-and-network keys plus a higher network-wide limit, so employees sharing an office IP do not share a ten-attempt lockout. Password verification runs asynchronously with two active jobs and a bounded queue. Expired sessions, invitations and throttle records are cleaned in bounded batches.
