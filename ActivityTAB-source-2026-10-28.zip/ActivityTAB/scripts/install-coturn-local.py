import urllib.request,urllib.parse,json,hashlib,tarfile,pathlib,subprocess,shutil
root=pathlib.Path(__file__).resolve().parents[1]/'work'/'coturn-runtime'
root.mkdir(parents=True,exist_ok=True)
packages=root/'packages';packages.mkdir(exist_ok=True)
seen=set();manifests=[]
def fetch(url,headers=None):
 with urllib.request.urlopen(urllib.request.Request(url,headers=headers or {}),timeout=60) as r:return r.read()
def install(name):
 if name in seen:return
 seen.add(name)
 f=json.loads(fetch('https://formulae.brew.sh/api/formula/'+urllib.parse.quote(name,safe='')+'.json'))
 if name=='coturn' and f['versions']['stable']!='4.18.0':raise RuntimeError('Coturn release changed; review security advisories before updating the pinned local runtime')
 for dep in f['dependencies']:install(dep)
 files=f['bottle']['stable']['files'];tag=next((x for x in ['arm64_sequoia','arm64_sonoma','arm64_ventura','all'] if x in files),None)
 if not tag:raise RuntimeError('No macOS 15-compatible bottle for '+name)
 bottle=files[tag];url=bottle['url'];sha=bottle['sha256'];archive=packages/(name.replace('@','-')+'-'+sha[:12]+'.tar.gz')
 if not archive.exists():
  try:data=fetch(url)
  except urllib.error.HTTPError as e:
   if e.code!=401:raise
   package=url.split('/v2/')[1].split('/blobs/')[0]
   token=json.loads(fetch('https://ghcr.io/token?service=ghcr.io&scope=repository:'+urllib.parse.quote(package,safe='/')+':pull'))['token']
   data=fetch(url,{'Authorization':'Bearer '+token})
  if hashlib.sha256(data).hexdigest()!=sha:raise RuntimeError('Checksum mismatch: '+name)
  archive.write_bytes(data)
 if hashlib.sha256(archive.read_bytes()).hexdigest()!=sha:raise RuntimeError('Cached checksum mismatch: '+name)
 with tarfile.open(archive) as t:
  # Reject escaping archive paths; Homebrew symlinks must remain inside the extracted tree.
  destination=(root/'cellar').resolve();destination.mkdir(exist_ok=True);links=[]
  for entry in t.getmembers():
   target=(destination/entry.name).resolve()
   if not str(target).startswith(str(destination)+'/'):raise RuntimeError('Unsafe archive path')
   if entry.isdir():target.mkdir(parents=True,exist_ok=True)
   elif entry.isfile():
    target.parent.mkdir(parents=True,exist_ok=True)
    with t.extractfile(entry) as source,target.open('wb') as output:shutil.copyfileobj(source,output)
    target.chmod(entry.mode&0o777)
   elif entry.issym():links.append((target,entry.linkname))
   elif entry.islnk():links.append((target,str(destination/entry.linkname)))
  for target,link in links:
   resolved=(target.parent/link).resolve()
   if not str(resolved).startswith(str(destination)+'/'):continue
   target.parent.mkdir(parents=True,exist_ok=True)
   if not target.exists():target.symlink_to(link)

 manifests.append({'name':name,'version':f['versions']['stable'],'source':url,'sha256':sha,'tag':tag})
 print('Verified package:',name,f['versions']['stable'],flush=True)
install('coturn')
(root/'sources.json').write_text(json.dumps(manifests,indent=2))
# Keep the package payload intact; put relocated runtime copies in a separate folder.
bin_dir=root/'bin';lib_dir=root/'lib';bin_dir.mkdir(exist_ok=True);lib_dir.mkdir(exist_ok=True)
for p in (root/'cellar').glob('coturn/*/bin/*'):
 if p.is_file():shutil.copy2(p,bin_dir/p.name)
for p in (root/'cellar').rglob('*.dylib'):
 if p.is_file():shutil.copy2(p,lib_dir/p.name)
for p in [*bin_dir.iterdir(),*lib_dir.iterdir()]:
 try:deps=subprocess.check_output(['otool','-L',str(p)],text=True).splitlines()[1:]
 except subprocess.CalledProcessError:continue
 for line in deps:
  old=line.strip().split(' (')[0]
  if old.startswith('/usr/lib/') or old.startswith('/System/'):continue
  if '/opt/' in old or '/Cellar/' in old or old.startswith('@@') or old.startswith('@rpath/'):
   target=lib_dir/pathlib.Path(old).name
   if not target.exists():raise RuntimeError('Missing dependency '+old)
   relative='@loader_path/'+('' if p.parent==lib_dir else '../lib/')+target.name
   subprocess.run(['install_name_tool','-change',old,relative,str(p)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 subprocess.run(['codesign','--force','--sign','-',str(p)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
print('Isolated runtime installed:',root,flush=True)
